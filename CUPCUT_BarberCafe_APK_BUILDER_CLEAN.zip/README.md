# CUPCUT Barber Cafe — APK Builder

This repository is a clean Android APK build project for the CUPCUT Barber Cafe web app.

## Build on GitHub from a phone

1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Open **Actions**.
3. Select **Build CUPCUT Barber Cafe APK**.
4. Tap **Run workflow**.
5. Wait for the green check.
6. Open the completed run and download **CUPCUT-Barber-Cafe-APK**.

The workflow builds a debug APK, so no signing key or server is required for testing.

## Project structure

- `app/` — Android app and website assets
- `.github/workflows/build-apk.yml` — GitHub Actions APK builder
- `build.gradle` — Android Gradle plugin configuration
- `settings.gradle` — project configuration

The APK is produced at:
`app/build/outputs/apk/debug/app-debug.apk`
