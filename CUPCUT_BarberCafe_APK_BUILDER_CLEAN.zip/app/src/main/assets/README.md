CUPCUT V38 — clean reliability build. Fixes mobile hamburger navigation, menu rendering fallback, stale-cache asset versions, branch initialization stability, and removes remaining editorial numbering. Server/backend intentionally not included.

ADMIN ACCESS (NO SERVER)
-------------------------
Open admin.html directly from this folder. The public customer pages intentionally do not show an Admin button or link.
Local test accounts: owner / 2468, manager / 1357, staff / 1111.

IMPORTANT: This is browser/local-storage mode. Do not expect data to sync between devices until a server/database is approved.

## V40 visual polish
The homepage includes a premium CupCut signature intro animation using the supplied logo, with reduced-motion support and no server requirement. The intro is session-based so it does not replay on every page refresh in the same browser session.


V43 production repair: preserves V41 content/animations and isolates modal scrolling from the page on touch and wheel input.
