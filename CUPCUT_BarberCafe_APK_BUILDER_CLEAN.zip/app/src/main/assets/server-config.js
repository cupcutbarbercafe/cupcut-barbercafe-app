/*
  CAFE ORDERING TEMPLATE — SERVER CONFIG

  Keep this empty while using the website in local/serverless mode.
  When you add your backend later, replace the value below with your API base URL.
*/
window.CAFE_API_BASE_URL = "";
window.CAFE_API_ENABLED = Boolean(window.CAFE_API_BASE_URL);

// Fallback branch choices for the serverless demo.
// In no-server mode, the customer pages read the admin-managed branch list from localStorage first.
// Keep these IDs stable for the initial branches.
window.CUPCUT_BRANCHES = [
  { id: "main", name: "Main Branch" },
  { id: "branch-2", name: "Branch 2" }
];
