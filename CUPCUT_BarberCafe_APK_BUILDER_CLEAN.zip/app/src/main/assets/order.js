const CART_KEY="cafe-template-cart", ORDERS_KEY="cafe-template-orders", LAST_KEY="cafe-template-last-order-id", THEME_KEY="cafe-template-theme";
const $=id=>document.getElementById(id);
let cart=[], orderType="Pickup", paymentMethod="Cash";
try{cart=JSON.parse(localStorage.getItem(CART_KEY)||"[]")}catch(e){cart=[]}

function getCustomerBranches(){
  const configured=Array.isArray(window.CUPCUT_BRANCHES)?window.CUPCUT_BRANCHES:[];
  const defaults=configured.length?configured:[{id:"main",name:"Main Branch"},{id:"branch-2",name:"Branch 2"}];
  try{
    const stored=JSON.parse(localStorage.getItem("cafe-template-branches")||"null");
    if(Array.isArray(stored)&&stored.length){
      return stored.filter(b=>b && b.active!==false && b.id && b.name).map(b=>({id:String(b.id),name:String(b.name)}));
    }
  }catch(e){}
  return defaults.map(b=>({id:String(b.id),name:String(b.name)}));
}
function renderCustomerBranches(){
  const select=$("customerBranch"); if(!select)return;
  const branches=getCustomerBranches();
  select.innerHTML=`<option value="" disabled>Select a branch</option>`+branches.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");
  const saved=localStorage.getItem("cafe-template-last-branch");
  if(saved && branches.some(b=>b.id===saved))select.value=saved; else select.value="";
}

function saveCart(){try{localStorage.setItem(CART_KEY,JSON.stringify(cart));return true}catch(e){return false}}
function money(n){return "₱"+Number(n||0).toLocaleString("en-PH")}
function total(){return cart.reduce((n,x)=>n+Number(x.price||0)*Number(x.qty||0),0)}
function renderCart(){
  const count=$("cartCount"), totalEl=$("orderTotal"), heroTotal=$("heroCartTotal"), status=$("heroCartStatus");
  if(count)count.textContent=cart.reduce((n,x)=>n+x.qty,0);
  if(totalEl)totalEl.textContent=money(total());
  if(heroTotal)heroTotal.textContent=money(total());
  if(status)status.textContent=cart.length?`${cart.reduce((n,x)=>n+x.qty,0)} item(s) ready for checkout.`:"Your cart is empty.";
  const box=$("orderItems"), empty=$("orderEmpty");
  if(!box)return;
  box.innerHTML="";
  if(!cart.length){if(empty)empty.hidden=false;return}
  if(empty)empty.hidden=true;
  cart.forEach((x,i)=>{
    const row=document.createElement("article");row.className="order-item";
    row.innerHTML=`<div><span class="order-item-cat">${esc(x.cat||"Menu")}</span><h3>${esc(x.name)}</h3><small>${esc(x.size||"")}${x.add?.length?" • "+esc(x.add.join(", ")):""}${x.note?" • "+esc(x.note):""}</small></div><div class="order-item-actions"><strong>${money(x.price*x.qty)}</strong><div><button data-a="-" data-i="${i}">−</button><b>${x.qty}</b><button data-a="+" data-i="${i}">+</button><button class="remove-btn" data-a="remove" data-i="${i}">Remove</button></div></div>`;
    row.querySelectorAll("button").forEach(b=>b.onclick=()=>changeCart(Number(b.dataset.i),b.dataset.a));
    box.appendChild(row);
  });
}
function changeCart(i,a){
  if(!cart[i])return;
  if(a==="+")cart[i].qty++;
  if(a==="-"){cart[i].qty--;if(cart[i].qty<=0)cart.splice(i,1)}
  if(a==="remove")cart.splice(i,1);
  saveCart();renderCart();
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

function openCheckout(){
  if(!cart.length){alert("Your cart is empty. Please add an item from the menu.");return}
  renderCheckoutSummary();
  $("checkoutLayer").classList.add("show");$("checkoutLayer").setAttribute("aria-hidden","false");document.body.classList.add("lock");
}
function closeCheckout(){if(!$("checkoutLayer"))return;$("checkoutLayer").classList.remove("show");$("checkoutLayer").setAttribute("aria-hidden","true");document.body.classList.remove("lock")}
function renderCheckoutSummary(){
  $("checkoutSummary").innerHTML=cart.map(x=>`<div class="summary-line"><span>${x.qty}× ${esc(x.name)}<small>${esc(x.size||"")}${x.add?.length?" • "+esc(x.add.join(", ")):""}</small></span><b>${money(x.price*x.qty)}</b></div>`).join("");
  $("checkoutTotal").textContent=money(total());
}
function updateOrderUI(){
  const wrap=$("deliveryAddressWrap"), address=$("deliveryAddress"), platformWrap=$("deliveryPlatformWrap"), platform=$("deliveryPlatform"), pickupWrap=$("pickupTimeWrap"), pickupTime=$("pickupTime");
  if(wrap)wrap.hidden=orderType!=="Delivery";
  if(address)address.required=orderType==="Delivery";
  if(platformWrap)platformWrap.hidden=orderType!=="Delivery";
  if(platform)platform.required=orderType==="Delivery";
  if(pickupWrap)pickupWrap.hidden=orderType!=="Pickup";
  if(pickupTime)pickupTime.required=orderType==="Pickup";
  document.querySelectorAll(".order-type").forEach(b=>b.classList.toggle("active",b.dataset.type===orderType));
  document.querySelectorAll(".payment-choice").forEach(b=>b.classList.toggle("active",b.dataset.payment===paymentMethod));
  if($("qrPlaceholder"))$("qrPlaceholder").hidden=paymentMethod!=="QR PH";
}
function orderText(){
  const branch=$("customerBranch")?.selectedOptions?.[0]?.textContent||"Main Branch",name=$("customerName").value.trim()||"Not provided",phone=$("customerPhone").value.trim()||"Not provided",email=$("customerEmail").value.trim()||"Not provided",address=$("deliveryAddress").value.trim()||"Not provided",platform=$("deliveryPlatform")?.value||"Not selected",pickupTime=$("pickupTime")?.value||"Not provided",note=$("orderNote").value.trim()||"None";
  return `CUPCUT THE BARBER CAFE ORDER\nBranch: ${branch}\nName: ${name}\nPhone: ${phone}\nEmail: ${email}\nOrder type: ${orderType}\n${orderType==="Pickup"?`Pickup time: ${pickupTime}\n`:""}${orderType==="Delivery"?`Delivery platform: ${platform}\nDelivery address: ${address}\n`:""}Payment: ${paymentMethod}\n\n${cart.map(x=>`• ${x.qty}x ${x.name} — ₱${x.price*x.qty}${x.size?` (${x.size})`:""}${x.add?.length?` [${x.add.join(", ")}]`:""}${x.note?` — ${x.note}`:""}`).join("\n")}\n\nTOTAL: ${money(total())}\nInstructions: ${note}`;
}
function renderTrack(o){
  const result=$("trackResult");if(!result)return;
  result.classList.remove("hidden");
  if(!o){result.innerHTML="<b>ORDER NOT FOUND</b><p>Check your Order ID and phone number.</p>";return}
  if(o.status==="Cancelled"){result.innerHTML=`<div class="track-id">${esc(o.id)}</div><div class="track-status">CANCELLED</div><p>Your order was cancelled.</p>`;return}
  const steps=["New","Preparing","Ready","Completed"], current=Math.max(0,steps.indexOf(o.status));
  result.innerHTML=`<div class="track-id">${esc(o.id)}</div><div class="track-status">${esc((o.status||"New").toUpperCase())}</div><div class="track-steps">${steps.map((s,i)=>`<div class="track-step ${i<=current?"done":""} ${i===current?"current":""}"><b>${i+1}</b><span>${s}</span></div>`).join("")}</div><p><b>Branch:</b> ${esc(o.branchName||o.branchId||"Main Branch")} · <b>Total:</b> ${money(o.total)} · <b>Type:</b> ${esc(o.orderType||"Pickup")}</p>${o.status==="New"?'<button class="track-cancel" id="cancelCustomerOrder">Cancel Order</button>':""}`;
  $("cancelCustomerOrder")?.addEventListener("click",()=>cancelOrder(o));
}
function findOrder(id,phone){
  try{const orders=JSON.parse(localStorage.getItem(ORDERS_KEY)||"[]");return orders.find(o=>o.id.toUpperCase()===id.toUpperCase() && (!phone||o.customerPhone===phone))||null}catch(e){return null}
}
function lookup(){
  const id=$("trackOrderId").value.trim(),phone=$("trackPhone").value.trim();
  if(!id){alert("Please enter your Order ID.");return}
  renderTrack(findOrder(id,phone));
}
function cancelOrder(o){
  if(o.status!=="New")return;
  if(!confirm(`Cancel order ${o.id}?`))return;
  let orders=[];try{const parsed=JSON.parse(localStorage.getItem(ORDERS_KEY)||"[]");orders=Array.isArray(parsed)?parsed:[]}catch(e){return} const i=orders.findIndex(x=>x.id===o.id);
  if(i>=0){orders[i]={...orders[i],status:"Cancelled",updatedAt:new Date().toISOString(),cancellationSource:"customer"};localStorage.setItem(ORDERS_KEY,JSON.stringify(orders));renderTrack(orders[i])}
}
function applyTheme(){
  let saved=""; try{saved=localStorage.getItem(THEME_KEY)||""}catch(e){}
  const dark=saved==="dark";
  document.documentElement.setAttribute("data-theme",dark?"dark":"light");
  document.body.classList.toggle("dark",dark);
  if($("themeLabel"))$("themeLabel").textContent=dark?"DARK":"LIGHT";
}
function toggleTheme(){let saved="";try{saved=localStorage.getItem(THEME_KEY)||""}catch(e){};try{localStorage.setItem(THEME_KEY,saved==="dark"?"light":"dark")}catch(e){};applyTheme()}

function closeSide(){$("sideMenu")?.classList.remove("open");$("shade")?.classList.remove("open");document.body.classList.remove("lock")}
$("hamburger")?.addEventListener("click",()=>{$("sideMenu").classList.add("open");$("shade").classList.add("open");document.body.classList.add("lock")});
$("closeSide")?.addEventListener("click",closeSide);
$("shade")?.addEventListener("click",closeSide);
$("themeToggle")?.addEventListener("click",toggleTheme);
const sideContactToggle=$("sideContactToggle"), sideContactPanel=$("sideContactPanel");
sideContactToggle?.addEventListener("click",()=>{
  const open=!sideContactPanel.classList.contains("show");
  sideContactPanel.classList.toggle("show",open);
  sideContactToggle.setAttribute("aria-expanded",String(open));
  sideContactPanel.setAttribute("aria-hidden",String(!open));
  const chev=sideContactToggle.querySelector(".contact-chevron"); if(chev)chev.textContent=open?"⌃":"⌄";
});
document.querySelectorAll(".side-nav a").forEach(a=>a.addEventListener("click",closeSide));
$("checkoutButton")?.addEventListener("click",openCheckout);
$("closeCheckout")?.addEventListener("click",closeCheckout);
$("checkoutLayer")?.addEventListener("click",e=>{if(e.target===$("checkoutLayer"))closeCheckout()});
$("trackBtn")?.addEventListener("click",lookup);
document.querySelectorAll(".order-type").forEach(b=>b.addEventListener("click",()=>{orderType=b.dataset.type;updateOrderUI()}));
document.querySelectorAll(".payment-choice").forEach(b=>b.addEventListener("click",()=>{paymentMethod=b.dataset.payment;updateOrderUI()}));
$("confirmOrder")?.addEventListener("click",()=>{
  const name=$("customerName")?.value.trim()||"",phone=$("customerPhone")?.value.trim()||"",email=$("customerEmail")?.value.trim()||"",address=$("deliveryAddress")?.value.trim()||"",pickupTime=$("pickupTime")?.value||"";
  if(!name||!phone){alert("Please enter your name and phone number.");return}
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){alert("Please enter a valid email address.");return}
  if(orderType==="Delivery"&&!address){alert("Please enter your delivery address.");return}
  const deliveryPlatform=$("deliveryPlatform")?.value||"";
  if(orderType==="Delivery"&&!deliveryPlatform){alert("Please choose your delivery platform before placing the order.");$("deliveryPlatform")?.focus();return}
  if(orderType==="Pickup"&&!pickupTime){alert("Please select your pickup time before placing the order.");$("pickupTime")?.focus();return}
  const branchId=$("customerBranch")?.value||"main", branchName=$("customerBranch")?.selectedOptions?.[0]?.textContent||"Main Branch"; if(!branchId){alert("Please choose your receiving branch before placing the order.");$("customerBranch")?.focus();return} localStorage.setItem("cafe-template-last-branch",branchId); const order={id:"CC-"+Date.now().toString(36).toUpperCase(),createdAt:new Date().toISOString(),branchId,branchName,customerName:name,customerPhone:phone,customerEmail:email,orderType,pickupTime,deliveryAddress:address,deliveryPlatform,paymentMethod,specialInstructions:$("orderNote").value.trim(),items:cart.map(x=>({name:x.name,qty:x.qty,size:x.size||"",add:x.add||[],note:x.note||"",price:x.price})),total:total(),status:"New"};
  let orders=[];
  try{const raw=localStorage.getItem(ORDERS_KEY);const parsed=raw?JSON.parse(raw):[];orders=Array.isArray(parsed)?parsed:[]}catch(e){orders=[]}
  orders.unshift(order);
  try{localStorage.setItem(ORDERS_KEY,JSON.stringify(orders));localStorage.setItem(LAST_KEY,order.id)}catch(e){alert("Your browser blocked local storage, so this order cannot be saved locally.");return}
  window.dispatchEvent(new CustomEvent("cupcut-orders-updated"));
  $("confirmationOrderId").textContent="#"+order.id;$("checkoutForm").hidden=true;$("orderConfirmation").hidden=false;
  $("trackOrderId").value=order.id;$("trackPhone").value=phone;renderTrack(order);
  navigator.clipboard?.writeText(orderText()).catch(()=>{});
  // Keep the cart visible until confirmation; then clear it so a new order starts clean.
  cart=[];saveCart();renderCart();
});
$("trackMyOrderNow")?.addEventListener("click",()=>{closeCheckout();$("trackOrder").scrollIntoView({behavior:"smooth"})});
$("cancelMyOrderNow")?.addEventListener("click",()=>{$("trackOrder").scrollIntoView({behavior:"smooth"});});
$("messengerOrder")?.addEventListener("click",async()=>{const text=orderText();try{await navigator.clipboard.writeText(text);alert("Order copied. Paste it into Messenger after it opens.");}catch(e){}window.open("https://www.facebook.com/share/1JVt6YSN2e/","_blank","noopener,noreferrer")});
try{const last=localStorage.getItem(LAST_KEY);if(last)$("trackOrderId").value=last}catch(e){}
applyTheme();renderCart();updateOrderUI();




// Third-party delivery apps managed from Admin > Delivery Apps.
function getDeliveryApps(){
  try{
    const raw=JSON.parse(localStorage.getItem("cafe-template-delivery-apps")||"[]");
    return Array.isArray(raw)?raw.filter(a=>a&&a.active!==false&&a.name&&a.url).map(a=>({id:String(a.id||a.name),name:String(a.name),url:String(a.url),note:String(a.note||"")})):[];
  }catch(e){return []}
}
function renderDeliveryApps(){
  const wrap=$("deliveryPlatformWrap"), choices=$("deliveryAppsChoices"), select=$("deliveryPlatform"), hint=$("deliveryAppOpenHint");
  if(!choices||!select)return;
  const apps=getDeliveryApps();
  select.innerHTML='<option value="">Choose delivery platform</option>'+apps.map(a=>`<option value="${esc(a.name)}">${esc(a.name)}</option>`).join("");
  choices.innerHTML=apps.length?apps.map((a,i)=>`<button type="button" class="delivery-app-choice" data-app-index="${i}"><span aria-hidden="true">↗</span><b>${esc(a.name)}</b><small>${esc(a.note||"OPEN DELIVERY APP")}</small></button>`).join(""):'<div class="delivery-none">Delivery apps will appear here when the admin adds their links.</div>';
  choices.querySelectorAll(".delivery-app-choice").forEach(btn=>btn.addEventListener("click",()=>{
    const app=apps[Number(btn.dataset.appIndex)]; if(!app)return;
    select.value=app.name;
    choices.querySelectorAll(".delivery-app-choice").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    if(hint){hint.hidden=false;hint.textContent=`Opening ${app.name}…`}
    window.open(app.url,"_blank","noopener,noreferrer");
  }));
  if(hint && !select.value) hint.hidden=true;
  if(wrap) wrap.dataset.appCount=String(apps.length);
}
window.addEventListener("cupcut-delivery-apps-updated",renderDeliveryApps);

/* CupCut UX helpers — works entirely client-side */
(function(){
  'use strict';

  function toast(message){
    let t=document.querySelector('.ux-toast');
    if(!t){
      t=document.createElement('div');
      t.className='ux-toast';
      document.body.appendChild(t);
    }
    t.textContent=message;
    t.classList.add('show');
    clearTimeout(window.__cupcutToast);
    window.__cupcutToast=setTimeout(()=>t.classList.remove('show'),2200);
  }
  window.cupcutToast=toast;

  // Back-to-top control
  const top=document.createElement('button');
  top.className='ux-top';
  top.type='button';
  top.setAttribute('aria-label','Back to top');
  top.textContent='↑';
  document.body.appendChild(top);
  const sync=()=>top.classList.toggle('show',window.scrollY>500);
  window.addEventListener('scroll',sync,{passive:true});
  top.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  sync();

  // Prevent accidental double-submits on forms.
  document.addEventListener('submit',function(e){
    const form=e.target;
    if(!form || form.dataset.uxLocked==='1') return;
    const submit=form.querySelector('button[type="submit"],input[type="submit"]');
    if(submit){
      form.dataset.uxLocked='1';
      const old=submit.textContent;
      submit.textContent='Processing…';
      setTimeout(()=>{
        form.dataset.uxLocked='0';
        submit.textContent=old;
      },3500);
    }
  });

  // Improve image loading for long menus.
  document.querySelectorAll('img').forEach((img,i)=>{
    if(i>2 && !img.hasAttribute('loading')) img.setAttribute('loading','lazy');
    if(!img.hasAttribute('decoding')) img.setAttribute('decoding','async');
  });
})();


document.addEventListener("DOMContentLoaded",()=>{renderCustomerBranches();updateOrderUI();renderCart();});
