function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}

const defaultItems=[["Hot Espresso Drinks","Hot Americano",110],["Hot Espresso Drinks","Hot Cappuccino",115],["Hot Espresso Drinks","Hot Cafe Latte",115],["Hot Espresso Drinks","Hot Sweetened Cafe Latte",140],["Hot Espresso Drinks","Hot Caramel Latte",130],["Hot Espresso Drinks","Hot Vanilla Latte",120],["Hot Espresso Drinks","Hot Chocolate Latte",130],["Hot Espresso Drinks","Hot Spanish Latte",130],["Hot Espresso Drinks","Hot White Mocha Latte",130],["Hot Espresso Drinks","Hot Salted Caramel Latte",130],["Iced Espresso Drinks","Iced Americano",115],["Iced Espresso Drinks","Iced Honey Americano",120],["Iced Espresso Drinks","Iced Cafe Latte",130],["Iced Espresso Drinks","Iced CMAC*",150],["Iced Espresso Drinks","CUPCUT’s Signature Latte**",160],["Iced Espresso Drinks","Iced Double Chocolate Latte",140],["Iced Espresso Drinks","Tres Leches Iced Latte",150],["Iced Espresso Drinks","Iced Caramel Mocha Latte",150],["Iced Espresso Drinks","Iced White Mocha Latte",145],["Iced Espresso Drinks","Iced Salted Caramel",145],["Iced Espresso Drinks","Iced Biscoff Latte",185],["Espresso Frappe","Caramel Espresso Frappe",170],["Espresso Frappe","Mocha Frappe",160],["Espresso Frappe","Vanilla Espresso Frappe",170],["Espresso Frappe","Cookies and Cream Espresso Frappe",170],["Espresso Frappe","Double Chocolate Espresso Frappe",180],["Espresso Frappe","Biscoff Frappe",200],["Milkshake","Strawberry Milkshake",150],["Milkshake","Ube Milkshake",145],["Milkshake","Dark Chocolate Milkshake",150],["Milkshake","Vanilla Milkshake",130],["Milkshake","Cookies and Cream MilkShake",145],["Milkshake","Oreo Chocolate Milkshake",155],["Everything Matcha","Hot Matcha Latte",145],["Everything Matcha","Iced Matcha Latte",150],["Everything Matcha","Hot Matcha Oat/Soy (Unsweetened)",160],["Everything Matcha","Iced Matcha Oat/Soy (Unsweetened)",160],["Everything Matcha","Iced Seasalt Matcha*",160],["Everything Matcha","Matcha Frappe",150],["Everything Matcha","Matcha Espresso Frappe",170],["Everything Matcha","Iced Matcha Strawberry",160],["Everything Matcha","Matcha Strawberry Frappe",180],["Everything Matcha","Iced Matcha Coconut Latte",160],["Everything Matcha","Iced Ube Cloud Matcha",170],["Everything Matcha","Matcha Oreo Frappe",170],["Non Coffee","Hot Double Chocolate",110],["Non Coffee","Hot Vanilla",110],["Non Coffee","Iced Dark Chocolate",120],["Non Coffee","Frizzy Lychee",130],["Non Coffee","Frizzy Blueberry",130],["Non Coffee","Frizzy Strawberry",130],["Non Coffee","Frizzy Fresh Lemon",145],["Non Coffee","Fresh Mango Shake",160],["All Day Breakfast","Tapa",160],["All Day Breakfast","Hungarian Sausage",150],["All Day Breakfast","Longanisa",130],["All Day Breakfast","Corned Beef",145],["All Day Breakfast","Bangus",160],["All Day Breakfast","Luncheon Meat",145],["Pasta/Waffles/Snacks","Nachos Overload",180],["Pasta/Waffles/Snacks","French Fries Overload",160],["Pasta/Waffles/Snacks","Tuna Sandwich",145],["Pasta/Waffles/Snacks","Ham and Egg Sandwich",145],["Pasta/Waffles/Snacks","Smoked Beef Sandwich",160],["Pasta/Waffles/Snacks","Chicken Alfredo Pasta",200],["Pasta/Waffles/Snacks","Creamy Carbonara",180],["Pasta/Waffles/Snacks","Chicken Pesto Pasta",200],["Pasta/Waffles/Snacks","Bacon Carbonara Pasta",190],["Pasta/Waffles/Snacks","Tuna Pesto Pasta",145],["Pasta/Waffles/Snacks","Nutella Belgian Waffles",150],["Pasta/Waffles/Snacks","Mango Waffles",140],["Pasta/Waffles/Snacks","Strawberry Waffles",160],["Pasta/Waffles/Snacks","Biscoff Waffles",160]];



const CONTENT_KEY="cafe-template-content";
const SITE_PHOTOS_KEY="cafe-template-site-photos";
function loadContentOverrides(){
  try{return JSON.parse(localStorage.getItem(CONTENT_KEY)||"{}")}catch(e){return {}}
}
function buildItems(){
  const overrides=loadContentOverrides();
  const base=defaultItems.map(x=>{
    const key=x[0]+"|"+x[1], o=overrides[key]||{};
    return [x[0],x[1],o.price!==undefined?o.price:x[2],o.image||x[3]||"",o.available!==false];
  });
  const custom=Array.isArray(overrides.customProducts)?overrides.customProducts.filter(x=>x&&x.name).map(x=>[x.category||"Other",x.name,Number(x.price)||0,x.image||"",x.available!==false]):[];
  return [...base,...custom];
}
window.CUPCUT_MENU_ITEMS=defaultItems;
let items=buildItems();
function loadSitePhotos(){try{return JSON.parse(localStorage.getItem(SITE_PHOTOS_KEY)||"{}")||{}}catch(e){return {}}}
function renderSitePhotos(){
  const photos=loadSitePhotos();
  const map={cafePhotoExterior:"exterior",cafePhotoInterior:"interior",cafePhotoBar:"bar",ownerPhoto:"owner"};
  Object.entries(map).forEach(([id,key])=>{
    const el=$(id); if(!el)return; const src=photos[key]||"";
    el.style.backgroundImage=src?`url("${src}")`:"none";
    el.classList.toggle("has-image",!!src);
    const ph=el.querySelector(".photo-placeholder"); if(ph)ph.classList.toggle("hidden",!!src);
  });
  document.querySelectorAll("[data-photo-key]").forEach(el=>{
    const src=photos[el.dataset.photoKey]||"";
    el.style.backgroundImage=src?`linear-gradient(180deg,transparent 30%,#000b),url("${src}")`:"";
    el.style.backgroundSize="cover";
    el.style.backgroundPosition="center";
  });
  const cover=document.querySelector(".cover-placeholder");
  if(cover && photos.exterior){cover.style.backgroundImage=`linear-gradient(180deg,#0002,#0009),url("${photos.exterior}")`;cover.style.backgroundSize="cover";cover.style.backgroundPosition="center";}
}

let categories=["All"];
const groups={};
// Keep the category bar limited to the intended top-level categories.
// Individual menu groups are handled through the `groups` map above.
let current="All", query="", cart=[], activeProduct=null, selectedSize="Regular", selectedAddOns=[], productQty=1, editingCartIndex=-1, orderType="Takeout", notificationPreference="web", paymentMethod="Cash";
try{cart=JSON.parse(localStorage.getItem("cafe-template-cart")||"[]")}catch(e){cart=[]}

function getCustomerBranches(){
  const configured=Array.isArray(window.CUPCUT_BRANCHES)?window.CUPCUT_BRANCHES:[];
  const defaults=configured.length?configured:[{id:"main",name:"Main Branch"},{id:"branch-2",name:"Branch 2"}];
  try{
    const stored=JSON.parse(localStorage.getItem("cafe-template-branches")||"null");
    if(Array.isArray(stored)&&stored.length){
      return stored.filter(b=>b && b.active!==false && b.id && b.name).map(b=>({id:String(b.id),name:String(b.name)}));
    }
  }catch(e){}
  return defaults.map(b=>({id:String(b.id),name:String(b.name)}));
}
function syncCustomerBranchField(){const s=$("customerBranch");if(!s)return;const bs=getCustomerBranches();s.innerHTML=bs.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");const saved=localStorage.getItem("cafe-template-last-branch");if(saved&&bs.some(b=>b.id===saved))s.value=saved}

const $=id=>document.getElementById(id);
function normalizeAddOnValue(v){ return Array.isArray(v) ? v : (v && v!=="None" ? [v] : []); }
function addOnLabel(list){ return list.length ? list.join(", ") : "None"; }
function filtered(){
  return items.filter(x=>{
    const cat=current==="All" || x[0]===current || (groups[current]||[]).includes(x[0]);
    return x[4] !== false && cat && (`${x[0]} ${x[1]}`.toLowerCase().includes(query.toLowerCase()));
  });
}
function button(label, active, fn){
  const b=document.createElement("button");b.className="filter"+(active?" active":"");b.textContent=label;b.onclick=fn;return b;
}
function renderCategories(){
  const discovered=[...new Set(items.map(x=>x[0]).filter(Boolean))];
  categories=["All",...discovered.filter(c=>c!=="All")];
  if(!$("categories") || !$("categoryToggle")) return;
  $("categories").innerHTML="";
  categories.forEach(c=>{
    const b=button(c,current===c,()=>{
      current=c;
      menuVisibleCount=12;
      renderCategories();
      render();
      closeCategories();
    });
    $("categories").appendChild(b);
  });
  $("categoryToggle").querySelector("span:nth-child(2)").textContent=current==="All"?"Categories":current;
}
function openCategories(){
  if(!$("categories") || !$("categoryToggle")) return;
  $("categories").classList.add("show");
  $("categories").setAttribute("aria-hidden","false");
  $("categoryToggle").setAttribute("aria-expanded","true");
  $("categoryToggle").classList.add("open");
}
function closeCategories(){
  if(!$("categories") || !$("categoryToggle")) return;
  $("categories").classList.remove("show");
  $("categories").setAttribute("aria-hidden","true");
  $("categoryToggle").setAttribute("aria-expanded","false");
  $("categoryToggle").classList.remove("open");
}
let menuVisibleCount=12;
function render(){
  const g=$("menuGrid"); if(!g) return;
  const data=filtered(); g.innerHTML="";
  if(!data.length){g.innerHTML='<div class="empty">No matching items.</div>';return}
  const visible=data.slice(0,menuVisibleCount);
  visible.forEach((x,i)=>{
    const [cat,name,price]=x;
    const card=document.createElement("article");card.className="menu-card";card.style.setProperty("--cc-i",Math.min(i,11));
    card.innerHTML=`<div class="photo"${x[3]?` style="background-image:url('${x[3]}');background-size:cover;background-position:center"`:""}>${x[3]?"":`<span>CUPCUT</span>`}</div><div class="card-body"><div class="card-top"><h3>${esc(name)}</h3><strong class="card-price">${price==null?"—":"₱"+Number(price).toLocaleString("en-PH")}</strong></div><p>${cat==="The Picks"?"One of our favorites.":"Made for the CUPCUT mood."}</p><div class="card-footer"><span class="tag">${esc(cat)}</span><button class="quick-add" type="button">CUSTOMIZE +</button></div></div>`;
    card.querySelector(".photo").onclick=()=>openProduct(x);
    card.querySelector(".quick-add").onclick=()=>openProduct(x);
    g.appendChild(card);
  });
  if(data.length>menuVisibleCount){
    const more=document.createElement("button");
    more.type="button";more.className="menu-load-more";more.textContent=`LOAD MORE · ${data.length-menuVisibleCount} REMAINING`;
    more.onclick=()=>{menuVisibleCount+=12;render()};
    g.appendChild(more);
  }
}
function renderPicks(){
  const g=$("picksGrid");
  if(!g)return;
  const picks=items.filter(x=>x[0]==="The Picks");
  g.innerHTML=picks.filter(x=>x[4]!==false).map(x=>`<article class="pick"><div class="pick-photo photo" role="button" tabindex="0" aria-label="Customize ${x[1]}"${x[3]?` style="background-image:url('${x[3]}');background-size:cover;background-position:center"`:""}>${x[3]?"":`<span>CUPCUT</span>`}<small>Tap to customize</small></div><div class="pick-body"><strong>${x[1]}</strong><p>Staff favorite from CUPCUT.</p><div class="pick-footer"><span>₱${x[2]}</span><button type="button" data-pick="${x[1]}">Customize +</button></div></div></article>`).join("");
  g.querySelectorAll("[data-pick]").forEach(b=>b.onclick=()=>openProduct(picks.find(x=>x[1]===b.dataset.pick)));
  g.querySelectorAll(".pick-photo").forEach(photo=>{
    const open=()=>openProduct(picks.find(x=>x[1]===photo.closest(".pick").querySelector("[data-pick]").dataset.pick));
    photo.onclick=open;
    photo.onkeydown=e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open();}};
  });
}
function openProduct(x){
  if(!x || !$('productLayer')) return;
  activeProduct=x;productQty=1;selectedSize="Regular";selectedAddOns=[];
  $("productCategory").textContent=x[0];$("productName").textContent=x[1];$("productDescription").textContent="Choose your options, add a note, then add it to your cart.";
  $("note").value=""; $("qty").textContent="1";

  // Sizes are intentionally hidden until configured by the admin.
  // Add-ons are grouped by menu type so food/cakes can use their own list.
  $("sizeBlock").style.display="none";
  $("sizeOptions").innerHTML="";
  const savedAddOns=loadContentOverrides().addOns||{};
  const drinkCategories=["Hot Espresso Drinks","Iced Espresso Drinks","Espresso Frappe","Milkshake","Everything Matcha","Non Coffee"];
  const cakeCategories=["Cakes","Cakes & Pastries","Cake & Pastries","Pastries"];
  const addOnGroup=drinkCategories.includes(x[0])?"drink":(cakeCategories.includes(x[0])?"cake":"food");
  const addOns=Array.isArray(savedAddOns[addOnGroup])?savedAddOns[addOnGroup]:[];
  $("addOnBlock").style.display=addOns.length?"block":"none";
  $("addOnOptions").innerHTML=addOns.map(s=>`<button type="button" class="option" data-v="${esc(s)}" aria-pressed="false">${esc(s)}</button>`).join("");
  selectedAddOns=[];
  document.querySelectorAll("#addOnOptions .option").forEach(b=>b.onclick=()=>toggleAddOn(b));
  updateProductPrice();$("productLayer").classList.add("show");lockPageScroll();
}
function selectOption(sel,b,setter){document.querySelectorAll(sel+" .option").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");setter(b.dataset.v);updateProductPrice()}
function toggleAddOn(b){
  const v=b.dataset.v;
  if(!v)return;
  if(v==="None"){
    selectedAddOns=[];
  }else if(selectedAddOns.includes(v)){
    selectedAddOns=selectedAddOns.filter(x=>x!==v);
  }else{
    selectedAddOns=[...selectedAddOns.filter(x=>x!=="None"),v];
  }
  document.querySelectorAll("#addOnOptions .option").forEach(x=>{
    const on=x.dataset.v==="None" ? selectedAddOns.length===0 : selectedAddOns.includes(x.dataset.v);
    x.classList.toggle("selected",on);
    x.setAttribute("aria-pressed",String(on));
  });
  updateProductPrice();
}
function updateProductPrice(){
  if(!activeProduct)return;
  let p=activeProduct[2]||0;p+=selectedAddOns.reduce((sum,v)=>{const m=String(v).match(/₱(\d+)/);return sum+(m?Number(m[1]):0)},0);
  if($("productPrice")) $("productPrice").textContent="₱"+(p*productQty);
}
function addActive(){
  let p=activeProduct[2]||0;p+=selectedAddOns.reduce((sum,v)=>{const m=String(v).match(/₱(\d+)/);return sum+(m?Number(m[1]):0)},0);
  const note=$("note")?.value.trim()||"";
  const key=`${activeProduct[0]}|${activeProduct[1]}|${selectedSize}|${selectedAddOns.join(",")}|${note}`;
  if(editingCartIndex>=0 && cart[editingCartIndex]){
    cart[editingCartIndex]={...cart[editingCartIndex],key,name:activeProduct[1],cat:activeProduct[0],size:selectedSize,add:[...selectedAddOns],note,price:p,qty:productQty};
    editingCartIndex=-1;
  }else{
    const found=cart.find(x=>x.key===key);if(found)found.qty+=productQty;else cart.push({key,name:activeProduct[1],cat:activeProduct[0],size:selectedSize,add:[...selectedAddOns],note,price:p,qty:productQty});
  }
  saveCart(); closeProduct();renderCart();
  const cartButton=$("cartButton")||document.querySelector(".cart-button");
  if(cartButton){
    cartButton.classList.remove("cc-cart-pulse");
    void cartButton.offsetWidth;
    cartButton.classList.add("cc-cart-pulse");
    setTimeout(()=>cartButton.classList.remove("cc-cart-pulse"),500);
  }
}
function renderCart(){
  const count=$("cartCount"); if(count) count.textContent=cart.reduce((a,x)=>a+x.qty,0);
  const box=$("cartItems"); if(!box) return; box.innerHTML="";
  if(!cart.length){box.innerHTML='<div class="cart-empty">Your cart is waiting.<br>Add something delicious.</div>';if($("cartTotal"))$("cartTotal").textContent="₱0";return}
  let total=0;
  cart.forEach((x,i)=>{
    total+=x.price*x.qty;
    const d=document.createElement("div");d.className="cart-item";
    d.innerHTML=`<div class="cart-item-main"><strong>${x.name}</strong><small>${x.cat} • ${x.size}${x.add&&x.add.length?" • "+x.add.join(", "):""}${x.note?" • "+x.note:""}</small><div class="cart-controls"><button type="button" data-a="-" aria-label="Decrease quantity">−</button><b>${x.qty}</b><button type="button" data-a="+" aria-label="Increase quantity">+</button><button type="button" class="cart-edit" data-a="edit">Edit</button><button type="button" class="remove-btn" data-a="remove">Remove</button></div></div><b class="cart-item-price">₱${x.price*x.qty}</b>`;
    d.querySelectorAll("button").forEach(b=>b.onclick=()=>changeCart(i,b.dataset.a));
    box.appendChild(d);
  });
  if($("cartTotal")) $("cartTotal").textContent="₱"+total;
}
function changeCart(i,a){
  if(a==="+")cart[i].qty++;
  if(a==="-"){cart[i].qty--;if(cart[i].qty<=0)cart.splice(i,1)}
  if(a==="remove")cart.splice(i,1);
  if(a==="edit"){
    const x=cart[i]; const source=items.find(v=>v[0]===x.cat&&v[1]===x.name); if(source){
      editingCartIndex=i; openProduct(source); productQty=x.qty; selectedSize=x.size||"Regular"; selectedAddOns=x.add||[]; $("note").value=x.note||"";
      document.querySelectorAll("#sizeOptions .option").forEach(b=>b.classList.toggle("selected",b.dataset.v===selectedSize));
      document.querySelectorAll("#addOnOptions .option").forEach(b=>{const on=b.dataset.v==="None"?selectedAddOns.length===0:selectedAddOns.includes(b.dataset.v);b.classList.toggle("selected",on);b.setAttribute("aria-pressed",String(on))});
      $("qty").textContent=productQty; updateProductPrice(); return;
    }
  }
  saveCart(); renderCart()
}
function saveCart(){try{localStorage.setItem("cafe-template-cart",JSON.stringify(cart))}catch(e){}}
window.lockPageScroll=function lockPageScroll(){
  if(document.body.classList.contains("lock")) return;
  const y=window.scrollY||window.pageYOffset||0;
  document.body.dataset.lockScrollY=String(y);
  document.body.style.top=(-y)+"px";
  document.body.classList.add("lock");
}
window.unlockPageScroll=function unlockPageScroll(){
  if(!document.body.classList.contains("lock")) return;
  const y=Number(document.body.dataset.lockScrollY||0);
  document.body.classList.remove("lock");
  document.body.style.top="";
  delete document.body.dataset.lockScrollY;
  window.scrollTo({top:y,left:0,behavior:"auto"});
}
function closeProduct(){if($("productLayer"))$("productLayer").classList.remove("show");unlockPageScroll()}
function openCart(){if(!$("cartLayer")){window.location.href="order.html";return}$("cartLayer").classList.add("show");lockPageScroll();renderCart()}
function closeCart(){if($("cartLayer"))$("cartLayer").classList.remove("show");unlockPageScroll()}
function openSide(){
  if(!$("sideMenu")) return;
  $("sideMenu").classList.add("open");
  $("shade")?.classList.add("open");
  lockPageScroll();
  $("sideMenu").setAttribute("aria-hidden","false");
  $("hamburger")?.setAttribute("aria-expanded","true");
}
function closeSide(){
  $("sideMenu")?.classList.remove("open");
  $("shade")?.classList.remove("open");
  unlockPageScroll();
  $("sideMenu")?.setAttribute("aria-hidden","true");
  $("hamburger")?.setAttribute("aria-expanded","false");
}

function applyTheme(dark){
  const isDark=Boolean(dark);
  document.body.classList.toggle("dark",isDark);
  document.documentElement.setAttribute("data-theme",isDark?"dark":"light");

  const toggle=$("themeToggle");
  const label=$("themeLabel");

  if(toggle){
    toggle.classList.toggle("dark",isDark);
    toggle.setAttribute("aria-pressed",String(isDark));
    toggle.setAttribute("aria-label",isDark?"Switch to light theme":"Switch to dark theme");
  }
  if(label) label.textContent=isDark?"DARK":"LIGHT";

  try{
    localStorage.setItem("cafe-template-theme",isDark?"dark":"light");
  }catch(e){}
}

let savedTheme=null;
try{
  savedTheme=localStorage.getItem("cafe-template-theme");
}catch(e){}

// V36: initialize critical navigation first so one optional feature cannot break the menu.
applyTheme(savedTheme==="dark");

if($("themeToggle")) $("themeToggle").onclick=()=>{
  applyTheme(!document.body.classList.contains("dark"));
};

// Defensive hamburger binding: the navigation must work even if another optional
// component later throws an exception.
const hamburgerEl=$("hamburger"), sideMenuEl=$("sideMenu"), shadeEl=$("shade"), closeSideEl=$("closeSide");
if(hamburgerEl){ hamburgerEl.onclick=(e)=>{ e.preventDefault(); openSide(); }; }
if(closeSideEl){ closeSideEl.onclick=(e)=>{ e.preventDefault(); closeSide(); }; }
if(shadeEl){ shadeEl.onclick=closeSide; }

document.querySelectorAll(".side-nav a").forEach(a=>{
  a.addEventListener("click",()=>closeSide());
});

// Contact in the hamburger is an in-drawer toggle, not a jump to the bottom contact section.
const sideContactToggle = $("sideContactToggle");
const sideContactPanel = $("sideContactPanel");
if(sideContactToggle && sideContactPanel){
  sideContactToggle.onclick = (e) => {
    e.preventDefault();
    const open = sideContactPanel.classList.toggle("show");
    sideContactToggle.setAttribute("aria-expanded", String(open));
    sideContactPanel.setAttribute("aria-hidden", String(!open));
    const chevron = sideContactToggle.querySelector(".contact-chevron");
    if(chevron) chevron.textContent = open ? "⌃" : "⌄";
  };
}
if($("categoryToggle")) $("categoryToggle").onclick=()=>{
  $("categories").classList.contains("show")?closeCategories():openCategories();
};
document.addEventListener("click",e=>{
  if(!e.target.closest(".category-picker")) closeCategories();
});
if($("search")) $("search").oninput=e=>{query=e.target.value;menuVisibleCount=12;render()};
if($("clearSearch")) $("clearSearch").onclick=()=>{if($("search"))$("search").value="";query="";menuVisibleCount=12;render()};
if($("minus")) $("minus").onclick=()=>{if(productQty>1)productQty--; if($("qty"))$("qty").textContent=productQty;updateProductPrice()};
if($("plus")) $("plus").onclick=()=>{productQty++;if($("qty"))$("qty").textContent=productQty;updateProductPrice()};
if($("addToCart")) $("addToCart").onclick=addActive;
if($("closeProduct")) $("closeProduct").onclick=closeProduct;
if($("productLayer")) $("productLayer").onclick=e=>{if(e.target===$("productLayer"))closeProduct()};
if($("cartButton") && $("cartButton").tagName==="BUTTON") $("cartButton").onclick=openCart;
if($("closeCart")) $("closeCart").onclick=closeCart;
if($("continue")) $("continue").onclick=closeCart;
if($("checkout")) $("checkout").onclick=()=>{if(!cart.length){alert("Your cart is empty.");return}window.location.href="order.html";};
// Navigation is bound above with defensive handlers.
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeProduct();closeCart();closeSide()}});
if($("menuGrid")){
  try{render();}catch(e){console.error("CUPCUT menu render failed",e);}
  try{renderCategories();}catch(e){console.error("CUPCUT category render failed",e);}
}
try{renderPicks();}catch(e){console.error("CUPCUT picks render failed",e);}
try{renderCart();}catch(e){console.error("CUPCUT cart render failed",e);}
try{renderSitePhotos();}catch(e){console.error("CUPCUT photo render failed",e);}
function syncMenuCartCount(){ const n=cart.reduce((s,x)=>s+Number(x.qty||0),0); [$("cartCount"),$("menuCartCount")].forEach(el=>{if(el)el.textContent=n;}); }
syncMenuCartCount();


/* Multi add-on compatibility: select multiple add-ons safely. */
function enableMultiAddOns(){
  const box=$("addOnOptions"); if(!box) return;
  box.querySelectorAll("button").forEach(btn=>{
    if(btn.dataset.multiAddonBound) return;
    btn.dataset.multiAddonBound="1";
    btn.addEventListener("click",()=>{
      const v=btn.dataset.v || btn.dataset.value || btn.value || btn.textContent.trim();
      if(!v) return;
      if(v==="None"){
        selectedAddOns=[];
      }else{
        selectedAddOns=selectedAddOns.includes(v)
          ? selectedAddOns.filter(x=>x!==v)
          : [...selectedAddOns.filter(x=>x!=="None"),v];
      }
      box.querySelectorAll("button").forEach(b=>{
        const bv=b.dataset.v || b.dataset.value || b.value || b.textContent.trim();
        const on=bv==="None" ? selectedAddOns.length===0 : selectedAddOns.includes(bv);
        b.classList.toggle("selected",on);
        b.setAttribute("aria-pressed",String(on));
      });
      updateProductPrice();
    });
  });
}

/* =========================================================
   CUPCUT CAFE v6 — interaction polish
   ========================================================= */
(function(){
// Auto-close an open mobile category strip after choosing a category if it has a toggle.
  document.addEventListener("click",function(e){
    const category=e.target.closest(".category-bar button,.categories button,.filter-bar button");
    if(category) category.scrollIntoView({behavior:"smooth",block:"nearest",inline:"center"});
  });

  // Mark images as lazy-loaded unless explicitly eager.
  document.querySelectorAll("img:not([loading])").forEach(img=>img.loading="lazy");

  // Prevent accidental double-submit on order CTAs.
  document.addEventListener("click",function(e){
    const btn=e.target.closest("#addToCart,.add-to-cart,.checkout-btn");
    if(!btn || btn.dataset.busy==="1") return;
    if(btn.type==="submit"){
      btn.dataset.busy="1";
      setTimeout(()=>btn.dataset.busy="0",1200);
    }
  });
})();


/* v7 — restore reliable product-card clicking */
(function(){
  document.addEventListener("click", function(e){
    const card=e.target.closest(".menu-card,.card,[data-product]");
    if(!card) return;
    if(e.target.closest("button,a,input,textarea,select,[role='button']")) return;

    // Prefer an existing product/card action.
    const action=card.querySelector(
      'button.add-to-cart,button[data-action="add"],button[data-product],button'
    );
    if(action){
      action.click();
      return;
    }

    // If the app exposes a product id/data attribute, use the existing product
    // renderer when available.
    const id=card.dataset.product || card.dataset.id;
    if(id && typeof window.openProduct==="function") window.openProduct(id);
  });
})();

window.openProduct=openProduct;


/* ===== v15 PRO ORDERING UPGRADE ===== */
(function(){
  const layer=$("checkoutLayer"); if(!layer) return;
  function total(){return cart.reduce((n,x)=>n+x.price*x.qty,0)}
  function summary(){
    const box=$("checkoutSummary"); box.innerHTML=cart.length?cart.map(x=>`<div class="summary-line"><span>${x.qty}× ${x.name}<small>${x.size}${x.add&&x.add.length?" • "+x.add.join(", "):""}${x.note?" • "+x.note:""}</small></span><b>₱${x.price*x.qty}</b></div>`).join(""):"<div>Your cart is empty.</div>";
    $("checkoutTotal").textContent="₱"+total();
  }
  function openCheckout(){if(!cart.length){alert("Your cart is empty.");return} summary();
    const form=$("checkoutForm"), confirmation=$("orderConfirmation");
    if(form) form.hidden=false; if(confirmation) confirmation.hidden=true;
    layer.classList.add("show");layer.setAttribute("aria-hidden","false");document.body.classList.add("lock")}
  function closeCheckout(){layer.classList.remove("show");layer.setAttribute("aria-hidden","true");document.body.classList.remove("lock")}
  function orderText(){
    const branch=$("customerBranch")?.selectedOptions?.[0]?.textContent||"Main Branch", name=$("customerName").value.trim()||"Not provided", phone=$("customerPhone").value.trim()||"Not provided", email=$("customerEmail")?.value.trim()||"Not provided", address=$("deliveryAddress")?.value.trim()||"Not provided", platform=$("deliveryPlatform")?.value||"Not selected", pickupTime=$("pickupTime")?.value||"Not provided", note=$("orderNote").value.trim()||"None";
    return `CUPCUT CAFE ORDER\nBranch: ${branch}\nName: ${name}\nPhone: ${phone}\nEmail: ${email}\nOrder type: ${orderType}\n${orderType==="Delivery"?`Delivery platform: ${platform}\nDelivery address: ${address}\n`:""}${orderType==="Pickup"?`Pickup time: ${pickupTime}\n`:""}Payment method: ${paymentMethod}\n\n${cart.map(x=>`• ${x.qty}x ${x.name} — ₱${x.price*x.qty}${x.size?` (${x.size})`:""}${x.add?.length?` [${x.add.join(", ")}]`:""}${x.note?` — ${x.note}`:""}`).join("\n")}\n\nTOTAL: ₱${total()}\nSpecial instructions: ${note}`;
  }
  $("checkout").onclick=openCheckout;
  $("closeCheckout").onclick=closeCheckout;
  layer.onclick=e=>{if(e.target===layer)closeCheckout()};
  function updatePaymentUI(){
    const cod=[...document.querySelectorAll(".payment-choice")].find(x=>x.dataset.payment==="COD");
    const isDelivery=orderType==="Delivery";
    if(cod){
      cod.disabled=!isDelivery;
      cod.title=!isDelivery?"Cash on Delivery is available for Delivery orders.":"";
      cod.setAttribute("aria-disabled",String(!isDelivery));
    }
    if(!isDelivery && paymentMethod==="COD") paymentMethod="Cash";
    document.querySelectorAll(".payment-choice").forEach(x=>{
      const selected=x.dataset.payment===paymentMethod;
      x.classList.toggle("active",selected);
      x.setAttribute("aria-pressed",String(selected));
    });
    const qr=$("qrPlaceholder");
    if(qr) qr.hidden=paymentMethod!=="QR PH";
  }
  function updateOrderTypeUI(){
    const wrap=$("deliveryAddressWrap");
    if(wrap) wrap.hidden=orderType!=="Delivery";
    const address=$("deliveryAddress");
    if(address) address.required=orderType==="Delivery";
    const platformWrap=$("deliveryPlatformWrap"), platform=$("deliveryPlatform");
    if(platformWrap) platformWrap.hidden=orderType!=="Delivery";
    if(platform) platform.required=orderType==="Delivery";
    const pickupWrap=$("pickupTimeWrap"), pickupTime=$("pickupTime");
    if(pickupWrap) pickupWrap.hidden=orderType!=="Pickup";
    if(pickupTime) pickupTime.required=orderType==="Pickup";
    updatePaymentUI();
  }
  document.querySelectorAll(".order-type").forEach(b=>b.onclick=()=>{orderType=b.dataset.type;document.querySelectorAll(".order-type").forEach(x=>x.classList.toggle("active",x===b));updateOrderTypeUI()});
  document.querySelectorAll(".payment-choice").forEach(b=>b.onclick=()=>{
    if(b.disabled)return;
    paymentMethod=b.dataset.payment;
    updatePaymentUI();
  });
  syncCustomerBranchField();
  updateOrderTypeUI();
  document.querySelectorAll(".notify-choice").forEach(b=>b.onclick=()=>{notificationPreference=b.dataset.notify;document.querySelectorAll(".notify-choice").forEach(x=>{const selected=x===b;x.classList.toggle("active",selected);x.setAttribute("aria-pressed",String(selected))})});
  $("confirmOrder").onclick=()=>{
    if(!$("customerName").value.trim()||!$("customerPhone").value.trim()){alert("Please enter your name and phone number first.");return}
    const email=$("customerEmail")?.value.trim()||"";
    if(email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){alert("Please enter a valid email address.");return}
    if(notificationPreference==="email" && !email){alert("Please enter your email address to use Email notifications.");return}
    const deliveryAddress=$("deliveryAddress")?.value.trim()||"";
    if(orderType==="Delivery" && !deliveryAddress){alert("Please enter your delivery address.");return}
    const deliveryPlatform=$("deliveryPlatform")?.value||"";
    if(orderType==="Delivery" && !deliveryPlatform){alert("Please choose your delivery platform before placing the order.");$("deliveryPlatform")?.focus();return}
    const pickupTime=$("pickupTime")?.value||"";
    if(orderType==="Pickup" && !pickupTime){alert("Please select your pickup time before placing the order.");$("pickupTime")?.focus();return}
    const text=orderText();
    // Create a local order immediately. If a server is configured, also send it
    // to the API. Local mode remains fully usable until the server is ready.
    const branchId=$("customerBranch")?.value||"main";
    const branchName=$("customerBranch")?.selectedOptions?.[0]?.textContent||"Main Branch";
    if($("customerBranch")&&!branchId){alert("Please choose your receiving branch before placing the order.");$("customerBranch")?.focus();return}
    localStorage.setItem("cafe-template-last-branch",branchId);
    const order={
      id:"CC-"+Date.now().toString(36).toUpperCase(),
      createdAt:new Date().toISOString(),
      branchId,
      branchName,
      customerName:$("customerName").value.trim(),
      customerPhone:$("customerPhone").value.trim(),
      customerEmail:email,
      notificationPreference,
      orderType,
      deliveryAddress,
      deliveryPlatform,
      pickupTime,
      paymentMethod,
      paymentStatus:paymentMethod==="QR PH"?"pending":"unpaid",
      specialInstructions:$("orderNote").value.trim(),
      items:cart.map(x=>({name:x.name,qty:x.qty,size:x.size||"",add:x.add||[],note:x.note||"",price:x.price})),
      total:total(),
      status:"New"
    };
    try{
      const orders=JSON.parse(localStorage.getItem("cafe-template-orders")||"[]");
      orders.unshift(order);
      localStorage.setItem("cafe-template-orders",JSON.stringify(orders));
    }catch(e){}
    if(window.CAFE_API_ENABLED){
      fetch(window.CAFE_API_BASE_URL+"/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(order)})
        .then(r=>{if(!r.ok)throw new Error("API order failed")})
        .catch(()=>console.warn("Server unavailable; local order record retained."));
    }
    window.__lastCafeOrderId=order.id; try{localStorage.setItem("cafe-template-last-order-id",order.id)}catch(e){}
    // Show the order confirmation INSIDE the checkout flow so customers immediately see tracking/cancellation.
    if($("confirmationOrderId")) $("confirmationOrderId").textContent="#"+order.id;
    const form=$("checkoutForm"), confirmation=$("orderConfirmation");
    if(form) form.hidden=true; if(confirmation) confirmation.hidden=false;
    window.__lastOrderForConfirmation=order;
    navigator.clipboard?.writeText(text).catch(()=>{});
    window.showTracking?.(order);
    alert("Order placed! Your Order ID is "+order.id+".");
    window.open("https://www.facebook.com/share/1JVt6YSN2e/","_blank","noopener,noreferrer");
  };
  $("trackMyOrderNow")?.addEventListener("click",()=>{
    const order=window.__lastOrderForConfirmation;
    if(order) window.showTracking?.(order);
    closeCheckout();
    setTimeout(()=>document.getElementById("trackOrder")?.scrollIntoView({behavior:"smooth",block:"start"}),50);
  });
  $("cancelMyOrderNow")?.addEventListener("click",()=>{
    const order=window.__lastOrderForConfirmation;
    if(!order || order.status!=="New") return;
    window.showTracking?.(order);
    setTimeout(()=>document.getElementById("cancelCustomerOrder")?.click(),50);
  });
  $("backToCheckout")?.addEventListener("click",()=>{
    const form=$("checkoutForm"), confirmation=$("orderConfirmation");
    if(form) form.hidden=false; if(confirmation) confirmation.hidden=true;
  });
  $("messengerOrder").onclick=async()=>{
    const text=orderText();
    try{await navigator.clipboard.writeText(text);alert("Order copied! Paste it into Messenger after it opens.");}catch(e){alert("Please copy your order details before sending them in Messenger.")}
    window.open("https://www.facebook.com/share/1JVt6YSN2e/","_blank","noopener,noreferrer");
  };
  const originalAdd=window.addActive;
  // Keep cart persistent whenever the page is hidden/reloaded.
  window.addEventListener("beforeunload",saveCart);
  // Restore checkout summary whenever cart is opened.
  const oldOpenCart=window.openCart;
  window.openCart=function(){oldOpenCart();};
  window.__cupcutOrderText=orderText;
})();

/* Static admin content sync: updates menu photos/prices/availability in the same browser. */
window.addEventListener("storage",e=>{
  if(e.key===CONTENT_KEY){
    items=buildItems();
    renderCategories();render();renderPicks();
  }
  if(e.key===SITE_PHOTOS_KEY) renderSitePhotos();
});

/* ===== V23 ORDER TRACKING / SERVER-READY ADAPTER ===== */
(function(){
  const steps=["New","Preparing","Ready","Completed"];
  const result=$("trackResult");
  function esc2(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
  function findLocal(id,phone){
    try{
      const orders=JSON.parse(localStorage.getItem("cafe-template-orders")||"[]");
      return orders.find(o=>o.id.toUpperCase()===id.toUpperCase() && (!phone || o.customerPhone===phone))||null;
    }catch(e){return null}
  }
  function render(o){
    if(!result)return;
    result.classList.remove("hidden");
    if(!o){result.innerHTML="<b>ORDER NOT FOUND</b><p>Check your Order ID and phone number.</p>";return}
    const status=o.status==="Cancelled"?"Cancelled":(steps.includes(o.status)?o.status:"New");
    if(status==="Cancelled"){
      result.innerHTML=`<div class="track-id">${esc2(o.id)}</div><div class="track-status">❌ ORDER CANCELLED</div><p>Please contact CupCut Cafe if you need help.</p>`;
      return;
    }
    const current=steps.indexOf(status);
    const canCancel=status==="New";
    result.innerHTML=`<div class="track-id">${esc2(o.id)}</div><div class="track-status">${esc2(status.toUpperCase())}</div>
      <div class="track-steps">${steps.map((s,i)=>`<div class="track-step ${i<=current?"done":""} ${i===current?"current":""}"><b>${i+1}</b><br>${s}</div>`).join("")}</div>
      <p><b>Total:</b> ₱${Number(o.total||0).toLocaleString("en-PH")} · <b>Type:</b> ${esc2(o.orderType||"Takeout")}</p>
      ${canCancel?`<button type="button" class="track-cancel" id="cancelCustomerOrder">Cancel Order</button><p class="track-cancel-help">You can cancel while your order is still new. Once preparation starts, cancellation is no longer available.</p>`:""}`;
    if(canCancel){
      $("cancelCustomerOrder")?.addEventListener("click",()=>cancelOrder(o));
    }
  }
  async function cancelOrder(o){
    if(o.status!=="New")return;
    if(!confirm(`Cancel order ${o.id}?\n\nThis cannot be undone.`))return;
    const updated={...o,status:"Cancelled",updatedAt:new Date().toISOString(),cancellationSource:"customer"};
    try{
      const orders=JSON.parse(localStorage.getItem("cafe-template-orders")||"[]");
      const i=orders.findIndex(x=>x.id===o.id);
      if(i>=0){orders[i]=updated;localStorage.setItem("cafe-template-orders",JSON.stringify(orders));}
    }catch(e){}
    render(updated);
    if(window.CAFE_API_ENABLED){
      try{
        const r=await fetch(window.CAFE_API_BASE_URL+"/orders/"+encodeURIComponent(o.id)+"/status",{method:"PATCH",headers:{"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify({status:"Cancelled",notify:true,notificationPreference:o.notificationPreference||"web",customer:{name:o.customerName||"",phone:o.customerPhone||"",email:o.customerEmail||""},source:"customer",paymentMethod:o.paymentMethod||"Cash",paymentStatus:o.paymentStatus||"unpaid"})});
        if(!r.ok)throw new Error("API cancellation failed");
      }catch(e){console.warn("Server cancellation sync failed; local cancellation retained.");}
    }
    alert("Order " + o.id + " has been cancelled.");
  }
  async function lookup(){
    const id=($("trackOrderId")?.value||"").trim(), phone=($("trackPhone")?.value||"").trim();
    if(!id){alert("Please enter your Order ID.");return}
    if(window.CAFE_API_ENABLED){
      try{
        const url=window.CAFE_API_BASE_URL+"/orders/"+encodeURIComponent(id)+(phone?"?phone="+encodeURIComponent(phone):"");
        const r=await fetch(url,{headers:{"Accept":"application/json"}});
        if(r.ok){render(await r.json());startPolling();return}
      }catch(e){}
    }
    render(findLocal(id,phone));
    startPolling();
  }
  let pollTimer=null;
  function startPolling(){
    clearInterval(pollTimer);
    pollTimer=setInterval(async()=>{
      const id=($("trackOrderId")?.value||"").trim(),phone=($("trackPhone")?.value||"").trim();
      if(!id)return;
      if(window.CAFE_API_ENABLED){
        try{
          const r=await fetch(window.CAFE_API_BASE_URL+"/orders/"+encodeURIComponent(id)+(phone?"?phone="+encodeURIComponent(phone):""));
          if(r.ok){render(await r.json());return}
        }catch(e){}
      }
      render(findLocal(id,phone));
    },10000);
  }
  window.showTracking=function(order){
    if($("trackOrderId"))$("trackOrderId").value=order.id;
    if($("trackPhone"))$("trackPhone").value=order.customerPhone||"";
    render(order);
    document.getElementById("trackOrder")?.scrollIntoView({behavior:"smooth",block:"start"});
    startPolling();
  };
  $("trackBtn")?.addEventListener("click",lookup);
  // Restore the last order on this browser for easy tracking after refresh.
  try{
    const last=localStorage.getItem("cafe-template-last-order-id");
    if(last&&$("trackOrderId"))$("trackOrderId").value=last;
  }catch(e){}
  const oldShow=window.showTracking;
  window.addEventListener("beforeunload",()=>clearInterval(pollTimer));
})();



/* CupCut UX helpers — works entirely client-side */
(function(){
  'use strict';

  function toast(message){
    let t=document.querySelector('.ux-toast');
    if(!t){
      t=document.createElement('div');
      t.className='ux-toast';
      document.body.appendChild(t);
    }
    t.textContent=message;
    t.classList.add('show');
    clearTimeout(window.__cupcutToast);
    window.__cupcutToast=setTimeout(()=>t.classList.remove('show'),2200);
  }
  window.cupcutToast=toast;

  // Back-to-top control
  const top=document.createElement('button');
  top.className='ux-top';
  top.type='button';
  top.setAttribute('aria-label','Back to top');
  top.textContent='↑';
  document.body.appendChild(top);
  const sync=()=>top.classList.toggle('show',window.scrollY>500);
  window.addEventListener('scroll',sync,{passive:true});
  top.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
  sync();

  // Prevent accidental double-submits on forms.
  document.addEventListener('submit',function(e){
    const form=e.target;
    if(!form || form.dataset.uxLocked==='1') return;
    const submit=form.querySelector('button[type="submit"],input[type="submit"]');
    if(submit){
      form.dataset.uxLocked='1';
      const old=submit.textContent;
      submit.textContent='Processing…';
      setTimeout(()=>{
        form.dataset.uxLocked='0';
        submit.textContent=old;
      },3500);
    }
  });

  // Improve image loading for long menus.
  document.querySelectorAll('img').forEach((img,i)=>{
    if(i>2 && !img.hasAttribute('loading')) img.setAttribute('loading','lazy');
    if(!img.hasAttribute('decoding')) img.setAttribute('decoding','async');
  });
})();


/* ===== CUPCUT V37 HARD FALLBACK =====
   Critical navigation remains usable even if a later optional script throws. */
(function(){
  try{
    var h=document.getElementById('hamburger'), m=document.getElementById('sideMenu'), sh=document.getElementById('shade'), c=document.getElementById('closeSide');
    if(h && m){
      h.addEventListener('click',function(e){
        e.preventDefault();
        m.classList.add('open');
        if(sh) sh.classList.add('open');
        m.setAttribute('aria-hidden','false');
        h.setAttribute('aria-expanded','true');
        document.body.classList.add('lock');
      },true);
    }
    if(c) c.addEventListener('click',function(e){e.preventDefault();m.classList.remove('open');if(sh)sh.classList.remove('open');document.body.classList.remove('lock');if(h)h.setAttribute('aria-expanded','false');},true);
  }catch(err){ console.warn('CUPCUT navigation fallback',err); }
})();


/* ===== V42 REPAIR: restore smooth section/card reveal without breaking no-JS rendering ===== */
(function(){
  'use strict';
  document.documentElement.classList.add('js-motion');
  const targets=document.querySelectorAll(
    '.cc-intro,.cc-split,.cc-values,.cc-menu-callout,.cc-album-head,.cc-album-grid'
  );
  if(!targets.length || !('IntersectionObserver' in window)){
    targets.forEach(el=>el.classList.add('cc-in'));
    return;
  }
  const reduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduced){targets.forEach(el=>el.classList.add('cc-in'));return;}
  targets.forEach((el,i)=>{
    el.classList.add('cc-reveal');
    if(el.classList.contains('cc-values')) el.style.transitionDelay='40ms';
    if(el.classList.contains('cc-menu-callout')) el.style.transitionDelay='70ms';
    if(el.classList.contains('cc-album-grid')) el.style.transitionDelay='100ms';
  });
  const io=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('cc-in');
      }else{
        entry.target.classList.remove('cc-in');
      }
    });
  },{threshold:.12,rootMargin:'0px 0px -7% 0px'});
  targets.forEach(el=>io.observe(el));
})();

/* =========================================================
   V51 — small client-side UX finishing layer
   ========================================================= */
(function(){
  'use strict';
  const root=document.documentElement;
  const prefersReduced=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Give theme changes a polished crossfade without changing the existing theme logic.
  const themeBtn=document.getElementById('themeToggle');
  if(themeBtn){
    themeBtn.addEventListener('click',function(){
      if(prefersReduced)return;
      root.classList.add('theme-transition');
      window.setTimeout(()=>root.classList.remove('theme-transition'),260);
    },true);
  }

  // Keep the cart badge lively when its number changes, without interfering with existing cart logic.
  const badges=[document.getElementById('cartCount'),document.getElementById('menuCartCount')].filter(Boolean);
  if(window.MutationObserver){
    badges.forEach(b=>{
      const observer=new MutationObserver(()=>{
        b.classList.remove('cc-count-pop');
        void b.offsetWidth;
        b.classList.add('cc-count-pop');
        window.setTimeout(()=>b.classList.remove('cc-count-pop'),320);
      });
      observer.observe(b,{childList:true,characterData:true,subtree:true});
    });
  }

  // Add keyboard-friendly escape handling for any open native-ish search/category controls.
  document.addEventListener('keydown',e=>{
    if(e.key==='/' && !/input|textarea|select/i.test(document.activeElement?.tagName||'')){
      const search=document.getElementById('search');
      if(search){e.preventDefault();search.focus();}
    }
  });

  // Add a tiny helper hint only where a real menu search exists.
  const search=document.getElementById('search');
  if(search && !search.getAttribute('aria-label')) search.setAttribute('aria-label','Search CupCut menu');
})();
