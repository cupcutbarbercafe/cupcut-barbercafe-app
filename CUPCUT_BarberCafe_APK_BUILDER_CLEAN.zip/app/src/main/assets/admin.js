(() => {
  const ORDERS_KEY = "cafe-template-orders";
  const ACCOUNTS_KEY = "cafe-template-admin-accounts";
  const CONTENT_KEY = "cafe-template-content";
  const SITE_PHOTOS_KEY = "cafe-template-site-photos";
  const DELIVERY_APPS_KEY = "cafe-template-delivery-apps";
  const BRANCHES_KEY = "cafe-template-branches";
  const DEFAULT_ACCOUNTS = [
    {username:"owner",password:"2468",role:"owner"},
    {username:"manager",password:"1357",role:"manager"},
    {username:"staff",password:"1111",role:"staff"}
  ];
  const DEFAULT_ITEMS = [["Hot Espresso Drinks","Hot Americano",110],["Hot Espresso Drinks","Hot Cappuccino",115],["Hot Espresso Drinks","Hot Cafe Latte",115],["Hot Espresso Drinks","Hot Sweetened Cafe Latte",140],["Hot Espresso Drinks","Hot Caramel Latte",130],["Hot Espresso Drinks","Hot Vanilla Latte",120],["Hot Espresso Drinks","Hot Chocolate Latte",130],["Hot Espresso Drinks","Hot Spanish Latte",130],["Hot Espresso Drinks","Hot White Mocha Latte",130],["Hot Espresso Drinks","Hot Salted Caramel Latte",130],["Iced Espresso Drinks","Iced Americano",115],["Iced Espresso Drinks","Iced Honey Americano",120],["Iced Espresso Drinks","Iced Cafe Latte",130],["Iced Espresso Drinks","Iced CMAC*",150],["Iced Espresso Drinks","CUPCUT’s Signature Latte**",160],["Iced Espresso Drinks","Iced Double Chocolate Latte",140],["Iced Espresso Drinks","Tres Leches Iced Latte",150],["Iced Espresso Drinks","Iced Caramel Mocha Latte",150],["Iced Espresso Drinks","Iced White Mocha Latte",145],["Iced Espresso Drinks","Iced Salted Caramel",145],["Iced Espresso Drinks","Iced Biscoff Latte",185],["Espresso Frappe","Caramel Espresso Frappe",170],["Espresso Frappe","Mocha Frappe",160],["Espresso Frappe","Vanilla Espresso Frappe",170],["Espresso Frappe","Cookies and Cream Espresso Frappe",170],["Espresso Frappe","Double Chocolate Espresso Frappe",180],["Espresso Frappe","Biscoff Frappe",200],["Milkshake","Strawberry Milkshake",150],["Milkshake","Ube Milkshake",145],["Milkshake","Dark Chocolate Milkshake",150],["Milkshake","Vanilla Milkshake",130],["Milkshake","Cookies and Cream MilkShake",145],["Milkshake","Oreo Chocolate Milkshake",155],["Everything Matcha","Hot Matcha Latte",145],["Everything Matcha","Iced Matcha Latte",150],["Everything Matcha","Hot Matcha Oat/Soy (Unsweetened)",160],["Everything Matcha","Iced Matcha Oat/Soy (Unsweetened)",160],["Everything Matcha","Iced Seasalt Matcha*",160],["Everything Matcha","Matcha Frappe",150],["Everything Matcha","Matcha Espresso Frappe",170],["Everything Matcha","Iced Matcha Strawberry",160],["Everything Matcha","Matcha Strawberry Frappe",180],["Everything Matcha","Iced Matcha Coconut Latte",160],["Everything Matcha","Iced Ube Cloud Matcha",170],["Everything Matcha","Matcha Oreo Frappe",170],["Non Coffee","Hot Double Chocolate",110],["Non Coffee","Hot Vanilla",110],["Non Coffee","Iced Dark Chocolate",120],["Non Coffee","Frizzy Lychee",130],["Non Coffee","Frizzy Blueberry",130],["Non Coffee","Frizzy Strawberry",130],["Non Coffee","Frizzy Fresh Lemon",145],["Non Coffee","Fresh Mango Shake",160],["All Day Breakfast","Tapa",160],["All Day Breakfast","Hungarian Sausage",150],["All Day Breakfast","Longanisa",130],["All Day Breakfast","Corned Beef",145],["All Day Breakfast","Bangus",160],["All Day Breakfast","Luncheon Meat",145],["Pasta/Waffles/Snacks","Nachos Overload",180],["Pasta/Waffles/Snacks","French Fries Overload",160],["Pasta/Waffles/Snacks","Tuna Sandwich",145],["Pasta/Waffles/Snacks","Ham and Egg Sandwich",145],["Pasta/Waffles/Snacks","Smoked Beef Sandwich",160],["Pasta/Waffles/Snacks","Chicken Alfredo Pasta",200],["Pasta/Waffles/Snacks","Creamy Carbonara",180],["Pasta/Waffles/Snacks","Chicken Pesto Pasta",200],["Pasta/Waffles/Snacks","Bacon Carbonara Pasta",190],["Pasta/Waffles/Snacks","Tuna Pesto Pasta",145],["Pasta/Waffles/Snacks","Nutella Belgian Waffles",150],["Pasta/Waffles/Snacks","Mango Waffles",140],["Pasta/Waffles/Snacks","Strawberry Waffles",160],["Pasta/Waffles/Snacks","Biscoff Waffles",160]];

  let filter="all", query="", branchFilter="main", currentUser=null, menuQuery="", menuCategory="all", reportPeriod="today", reportFrom="", reportTo="", reportBranch="main", graphBranch="main", workspaceBranch="main", globalAdminOpen=false;
  const $=id=>document.getElementById(id);
  const money=n=>"₱"+Number(n||0).toLocaleString("en-PH");
  const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  // Storage helpers are deliberately defensive so the admin still opens cleanly
  // if browser storage was blocked/corrupted.
  function readJSON(key,fallback){try{const raw=localStorage.getItem(key);return raw?JSON.parse(raw):fallback}catch(e){return fallback}}
  function writeJSON(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true}catch(e){return false}}
  function getAccounts(){
    const stored=readJSON(ACCOUNTS_KEY,null);
    let a=Array.isArray(stored)?stored.map(x=>({...x})): [];
    // Always keep the built-in local demo accounts available.
    // Older V38/V39 browser data may contain a partial/old account list.
    DEFAULT_ACCOUNTS.forEach(def=>{
      if(!a.some(x=>String(x.username||"").toLowerCase()===def.username)){
        a.push({...def});
      }
    });
    if(!a.length) a=DEFAULT_ACCOUNTS.map(x=>({...x}));
    writeJSON(ACCOUNTS_KEY,a);
    return a;
  }
  function saveAccounts(a){writeJSON(ACCOUNTS_KEY,a)}
  function getOrders(){const a=readJSON(ORDERS_KEY,[]);return Array.isArray(a)?a:[]}
  function getBranches(){
    const stored=readJSON(BRANCHES_KEY,null);
    const defaults=Array.isArray(window.CUPCUT_BRANCHES)&&window.CUPCUT_BRANCHES.length?window.CUPCUT_BRANCHES.map(b=>({id:String(b.id),name:String(b.name),active:true})):[{id:"main",name:"Main Branch",active:true},{id:"branch-2",name:"Branch 2",active:true}];
    let a=Array.isArray(stored)&&stored.length?stored.map(b=>({...b})):[];
    let changed=false;
    // Keep customer/admin branch IDs identical. This also repairs older Branch 2
    // records that were created with a generated admin-only ID.
    a.forEach(b=>{
      const n=String(b.name||"").trim().toLowerCase();
      if(n==="main branch" && b.id!=="main"){b.id="main";changed=true}
      if((n==="branch 2"||n==="branch-2") && b.id!=="branch-2"){b.id="branch-2";b.name="Branch 2";changed=true}
    });
    defaults.forEach(d=>{
      const existing=a.find(b=>b.id===d.id);
      if(!existing){a.push(d);changed=true}
      else if(existing.active===undefined){existing.active=true;changed=true}
    });
    if(!a.length)a=defaults;
    if(changed||!Array.isArray(stored))writeJSON(BRANCHES_KEY,a);
    return a;
  }
  function saveBranches(a){writeJSON(BRANCHES_KEY,a)}
  function branchName(id){const b=getBranches().find(x=>x.id===id);return b?b.name:(id?String(id):"Unassigned")}
  function normalizeOrderBranches(){const a=getOrders();let changed=false;a.forEach(o=>{if(!o.branchId){o.branchId="main";changed=true}});if(changed)saveOrders(a);return a}
  function saveOrders(a){writeJSON(ORDERS_KEY,a);window.dispatchEvent(new CustomEvent("cupcut-orders-updated"))}
  function workspaceLabel(){return workspaceBranch==="all"?"ALL BRANCHES":branchName(workspaceBranch)}
  function scopedBranch(id){return workspaceBranch!=="all"&&id!==workspaceBranch?false:true}
  function applyWorkspace(){
    const activeBranches=getBranches().filter(b=>b.active!==false);
    if(!activeBranches.length)return;
    if(!workspaceBranch||workspaceBranch==="all"||!activeBranches.some(b=>b.id===workspaceBranch))workspaceBranch=activeBranches[0].id;
    const sel=$("workspaceBranchSelect");
    if(sel){sel.innerHTML=activeBranches.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");sel.value=workspaceBranch;}
    const title=$("workspaceTitle"),hint=$("workspaceHint"); if(title)title.textContent=workspaceLabel(); if(hint)hint.textContent=workspaceBranch==="all"?"Network view — all branch operations and records.":`${workspaceLabel()} workspace — branch records stay separated.`;
    branchFilter=workspaceBranch;reportBranch=workspaceBranch;graphBranch=workspaceBranch;
    const inv=$("inventoryBranchFilter");if(inv){inv.value=workspaceBranch;inv.disabled=true;}
    const rep=$("reportBranchSelect");if(rep){rep.value=workspaceBranch;rep.disabled=true;}
    const graph=$("graphBranchSelect");if(graph){graph.value=workspaceBranch;graph.disabled=true;}
  }

  function getContent(){const a=readJSON(CONTENT_KEY,{});return a&&typeof a==="object"?a:{}}
  function saveContent(a){writeJSON(CONTENT_KEY,a)}
  function getSitePhotos(){const a=readJSON(SITE_PHOTOS_KEY,{});return a&&typeof a==="object"?a:{}}
  function saveSitePhotos(a){writeJSON(SITE_PHOTOS_KEY,a);}
  function renderSitePhotos(){
    const photos=getSitePhotos();
    ["exterior","interior","bar","owner"].forEach(k=>{
      const el=$("preview"+k.charAt(0).toUpperCase()+k.slice(1)); if(!el)return;
      const src=photos[k]||"";
      el.style.backgroundImage=src?`url("${src}")`:"none";
      el.classList.toggle("has-image",!!src);
      el.innerHTML=src?"":`<span>${k==="owner"?"OWNER / TEAM":"CAFE PHOTO"}</span>`;
    });
  }
  function keyOf(x){return x[0]+"|"+x[1]}
  function getCustomProducts(){try{const c=getContent();return Array.isArray(c.customProducts)?c.customProducts:[]}catch(e){return []}}
  function getAllItems(){return [...DEFAULT_ITEMS,...getCustomProducts().map(x=>[x.category,x.name,x.price,x.image||"",x.available!==false,true])] }
  function getAddOns(){
    const defaults={drink:[],food:[],cake:[]};
    try{
      const src=getContent().addOns||{};
      return {
        drink:Array.isArray(src.drink)?src.drink:[],
        food:Array.isArray(src.food)?src.food:[],
        cake:Array.isArray(src.cake)?src.cake:[]
      };
    }catch(e){return defaults}
  }
  function saveToast(msg){const t=document.getElementById("toast");if(!t)return;t.textContent=msg;t.classList.add("show");clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove("show"),1800)}

  function isToday(iso){
    const d=new Date(iso),n=new Date();
    return d.getFullYear()===n.getFullYear()&&d.getMonth()===n.getMonth()&&d.getDate()===n.getDate();
  }
  function dateTime(iso){return new Date(iso).toLocaleString("en-PH",{month:"short",day:"numeric",year:"numeric",hour:"numeric",minute:"2-digit"})}

  function startOfDay(d){const x=new Date(d);x.setHours(0,0,0,0);return x}
  function endOfDay(d){const x=new Date(d);x.setHours(23,59,59,999);return x}
  function startOfWeek(d){const x=startOfDay(d),day=x.getDay();x.setDate(x.getDate()-(day===0?6:day-1));return x}
  function getReportRange(){
    const now=new Date();
    if(reportPeriod==="today")return {from:startOfDay(now),to:endOfDay(now),label:"Today"};
    if(reportPeriod==="week"){const f=startOfWeek(now),t=new Date(f);t.setDate(t.getDate()+6);return {from:f,to:endOfDay(t),label:"This week"};}
    if(reportPeriod==="month"){const f=new Date(now.getFullYear(),now.getMonth(),1),t=new Date(now.getFullYear(),now.getMonth()+1,0);return {from:f,to:endOfDay(t),label:f.toLocaleDateString("en-PH",{month:"long",year:"numeric"})};}
    if(reportPeriod==="year"){const f=new Date(now.getFullYear(),0,1),t=new Date(now.getFullYear(),11,31);return {from:f,to:endOfDay(t),label:String(now.getFullYear())};}
    const f=reportFrom?startOfDay(new Date(reportFrom+"T00:00:00")):startOfDay(now),t=reportTo?endOfDay(new Date(reportTo+"T00:00:00")):endOfDay(f);
    return {from:f,to:t,label:`${f.toLocaleDateString("en-PH",{month:"short",day:"numeric",year:"numeric"})} – ${t.toLocaleDateString("en-PH",{month:"short",day:"numeric",year:"numeric"})}`};
  }
  function inRange(o,r){const d=new Date(o.createdAt);return Number.isFinite(d.getTime())&&d>=r.from&&d<=r.to}
  function itemCategory(name){
    const hit=getAllItems().find(x=>x[1].toLowerCase()===String(name||"").toLowerCase());
    return hit?hit[0]:"Other";
  }
  function reportOrdersForBranch(orders, branch){return branch==="all"?orders:orders.filter(o=>(o.branchId||"main")===branch)}
  function renderBranchReports(orders){
    const wrap=$("branchRecords"); if(!wrap)return;
    const branches=getBranches().filter(b=>b.active!==false);
    const list=branches.map(b=>{
      const bo=orders.filter(o=>(o.branchId||"main")===b.id), valid=bo.filter(o=>o.status!=="Cancelled"), completed=bo.filter(o=>o.status==="Completed");
      const sales=valid.reduce((a,o)=>a+Number(o.total||0),0), comp=completed.reduce((a,o)=>a+Number(o.total||0),0);
      return {b,bo,sales,comp,avg:valid.length?sales/valid.length:0};
    });
    const allValid=orders.filter(o=>o.status!=="Cancelled"),allSales=allValid.reduce((a,o)=>a+Number(o.total||0),0);
    const overall={b:{id:"all",name:"ALL BRANCHES"},bo:orders,sales:allSales,comp:orders.filter(o=>o.status==="Completed").reduce((a,o)=>a+Number(o.total||0),0),avg:allValid.length?allSales/allValid.length:0};
    const rows=[overall,...list];
    wrap.innerHTML=rows.map(x=>`<article class="branch-record-card ${reportBranch===x.b.id?"selected":""}">
      <div class="branch-record-head"><div><span class="eyebrow">${x.b.id==="all"?"NETWORK VIEW":"BRANCH RECORD"}</span><h3>📍 ${esc(x.b.name)}</h3></div><button class="secondary branch-report-btn" data-branch="${esc(x.b.id)}">${reportBranch===x.b.id?"VIEWING":"VIEW RECORDS"}</button></div>
      <div class="branch-record-stats"><div><small>ORDERS</small><strong>${x.bo.length}</strong></div><div><small>SALES</small><strong>${money(x.sales)}</strong></div><div><small>COMPLETED</small><strong>${money(x.comp)}</strong></div><div><small>AVG ORDER</small><strong>${money(x.avg)}</strong></div></div>
      <div class="branch-record-latest">${x.bo.length?x.bo.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,3).map(o=>`<div><span><b>${esc(o.id)}</b> · ${esc(o.customerName||"No name")}<small>${dateTime(o.createdAt)} · ${esc(o.status)}</small></span><strong>${money(o.total)}</strong></div>`).join(""):"<div class=\"report-empty\">No orders recorded for this branch in this period.</div>"}</div>
    </article>`).join("");
  }
  function renderSalesGraph(orders,r){
    const branches=getBranches().filter(b=>b.active!==false);
    const selector=$("graphBranchSelect"); if(selector){selector.innerHTML=`<option value="all">ALL BRANCHES</option>`+branches.map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");selector.value=graphBranch; if(selector.value!==graphBranch){graphBranch="all";selector.value="all"}}
    const scoped=reportOrdersForBranch(orders,graphBranch).filter(o=>o.status!=="Cancelled");
    const from=r.from,to=r.to,days=Math.max(1,Math.ceil((to-from+1)/(864e5))),daily={};
    for(let i=0;i<days;i++){const d=new Date(from);d.setDate(d.getDate()+i);daily[d.toISOString().slice(0,10)]=0}
    scoped.forEach(o=>{const k=new Date(o.createdAt).toISOString().slice(0,10);if(k in daily)daily[k]+=Number(o.total||0)});
    let keys=Object.keys(daily);
    if(keys.length>31){const grouped={};keys.forEach(k=>{const m=k.slice(0,7);grouped[m]=(grouped[m]||0)+daily[k]});keys=Object.keys(grouped);Object.assign(daily,grouped)}
    const vals=keys.map(k=>daily[k]),max=Math.max(...vals,1),w=760,h=250,pad=34;
    const points=keys.map((k,i)=>{const x=pad+(keys.length===1?0:i*(w-pad*2)/(keys.length-1));const y=h-pad-(daily[k]/max)*(h-pad*2);return [x,y]});
    const poly=points.map(p=>p.join(",")).join(" ");
    const labels=keys.map((k,i)=>{if(keys.length>12&&i%Math.ceil(keys.length/8)!==0&&i!==keys.length-1)return "";const d=new Date(k.length===7?k+"-01":k+"T00:00:00");return `<text x="${points[i][0]}" y="${h-8}" text-anchor="middle" class="graph-label">${esc(k.length===7?d.toLocaleDateString("en-PH",{month:"short"}):d.toLocaleDateString("en-PH",{month:"short",day:"numeric"}))}</text>`}).join("");
    const dots=points.map((p,i)=>`<circle cx="${p[0]}" cy="${p[1]}" r="4" class="graph-dot"><title>${esc(keys[i])} • ${money(daily[keys[i]])}</title></circle>`).join("");
    $("salesGraph").innerHTML=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Sales graph"><line x1="${pad}" y1="${pad}" x2="${pad}" y2="${h-pad}" class="graph-axis"/><line x1="${pad}" y1="${h-pad}" x2="${w-pad}" y2="${h-pad}" class="graph-axis"/><polyline points="${poly}" class="graph-line" fill="none"/>${dots}${labels}</svg><div class="graph-summary"><span><b>${esc(graphBranch==="all"?"All branches":branchName(graphBranch))}</b> · ${r.label}</span><strong>${money(scoped.reduce((a,o)=>a+Number(o.total||0),0))}</strong></div>`;
    $("graphHint").textContent=days>31?"Monthly totals":"Daily sales";
  }
  function renderReports(){
    const r=getReportRange(), all=getOrders(), orders=all.filter(o=>inRange(o,r)).filter(o=>scopedBranch(o.branchId||"main")), valid=orders.filter(o=>o.status!=="Cancelled"), completed=orders.filter(o=>o.status==="Completed");
    const selected=reportOrdersForBranch(orders,reportBranch), sValid=selected.filter(o=>o.status!=="Cancelled"), sCompleted=selected.filter(o=>o.status==="Completed");
    const sales=sValid.reduce((a,o)=>a+Number(o.total||0),0), completedSales=sCompleted.reduce((a,o)=>a+Number(o.total||0),0), avg=sValid.length?sales/sValid.length:0;
    $("reportOrders").textContent=selected.length;$("reportSales").textContent=money(sales);$("reportCompletedSales").textContent=money(completedSales);$("reportAverage").textContent=money(avg);$("reportRangeLabel").textContent=r.label;
    const from=r.from,to=r.to,days=Math.max(1,Math.ceil((to-from+1)/(864e5))), daily={};
    for(let i=0;i<days;i++){const d=new Date(from);d.setDate(d.getDate()+i);daily[d.toISOString().slice(0,10)]=0}
    valid.forEach(o=>{const k=new Date(o.createdAt).toISOString().slice(0,10);if(k in daily)daily[k]+=Number(o.total||0)});
    const vals=Object.values(daily),max=Math.max(...vals,1),keys=Object.keys(daily);
    $("graphHint").textContent=days>31?"Monthly view":"Daily view";
    $("salesGraph").innerHTML=keys.map((k,i)=>{const v=daily[k],h=Math.max(4,Math.round(v/max*100));const d=new Date(k+"T00:00:00");const label=days>31?d.toLocaleDateString("en-PH",{month:"short"}):d.toLocaleDateString("en-PH",{month:"short",day:"numeric"});return `<div class="trend-col" title="${esc(label)} • ${money(v)}"><div class="trend-bar" style="height:${h}%"></div><small>${esc(label)}</small></div>`}).join("");
    renderBranchReports(orders);renderSalesGraph(orders,r);
    const products={},categories={},statuses={};
    sValid.forEach(o=>(o.items||[]).forEach(i=>{const qty=Number(i.qty||0),value=Number(i.price||0)*qty;products[i.name]=(products[i.name]||{qty:0,value:0});products[i.name].qty+=qty;products[i.name].value+=value;const c=itemCategory(i.name);categories[c]=(categories[c]||0)+value}));
    selected.forEach(o=>statuses[o.status]=(statuses[o.status]||0)+1);
    const rank=(obj,valueKey)=>Object.entries(obj).sort((a,b)=>valueKey?b[1][valueKey]-a[1][valueKey]:b[1]-a[1]).slice(0,7);
    const prod=rank(products,"value");$("bestSellers").innerHTML=prod.length?prod.map((x,i)=>`<div class="rank-row"><span><b>#${i+1}</b>${esc(x[0])}<small>${x[1].qty} sold</small></span><strong>${money(x[1].value)}</strong></div>`).join(""):"<div class=\"report-empty\">No product sales in this period.</div>";
    const cat=rank(categories);$("categorySales").innerHTML=cat.length?cat.map(x=>`<div class="rank-row"><span>${esc(x[0])}</span><strong>${money(x[1])}</strong></div>`).join(""):"<div class=\"report-empty\">No category sales in this period.</div>";
    const st=rank(statuses);$("statusBreakdown").innerHTML=st.length?st.map(x=>`<div class="rank-row"><span>${esc(x[0])}</span><strong>${x[1]}</strong></div>`).join(""):"<div class=\"report-empty\">No orders in this period.</div>";
  }
  function reportRows(){
    const r=getReportRange();return reportOrdersForBranch(getOrders().filter(o=>inRange(o,r)),reportBranch).map(o=>[o.id,dateTime(o.createdAt),branchName(o.branchId),o.customerName||"",o.customerPhone||"",o.orderType||"Pickup",o.status,Number(o.total||0)]);
  }
  function exportReport(){
    const rows=[["Order ID","Date","Branch","Customer","Phone","Order Type","Status","Total"],...reportRows()];
    const csv=rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`cafe-report-${reportPeriod}-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);saveToast("Report exported");
  }

  function getDeliveryApps(){
    const a=readJSON(DELIVERY_APPS_KEY,null);
    if(Array.isArray(a)) return a.filter(x=>x&&x.name&&x.url).map((x,i)=>({id:String(x.id||('delivery-'+i)),name:String(x.name),url:String(x.url),note:String(x.note||''),active:x.active!==false}));
    const defaults=[{id:'foodpanda',name:'Foodpanda',url:'',note:'Open CUPCUT on Foodpanda',active:true},{id:'deliverya',name:'Deliverya',url:'',note:'Open CUPCUT on Deliverya',active:true}];
    writeJSON(DELIVERY_APPS_KEY,defaults); return defaults;
  }
  function saveDeliveryApps(a){writeJSON(DELIVERY_APPS_KEY,a);window.dispatchEvent(new CustomEvent('cupcut-delivery-apps-updated'));}
  function renderDeliveryApps(){
    const wrap=$("deliveryAppsManager"); if(!wrap)return; const apps=getDeliveryApps();
    wrap.innerHTML=apps.length?apps.map(a=>`<article class="delivery-app-card ${a.active?'is-active':'is-off'}"><div class="delivery-app-icon">↗</div><div class="delivery-app-main"><span class="eyebrow">${a.active?'VISIBLE TO CUSTOMERS':'HIDDEN'}</span><h3>${esc(a.name)}</h3><p>${esc(a.note||'Third-party delivery service')}</p><small>${esc(a.url||'No link saved')}</small></div><div class="delivery-app-actions"><label class="delivery-active"><input type="checkbox" data-delivery-action="toggle" data-id="${esc(a.id)}" ${a.active?'checked':''}> SHOW</label><button class="secondary" data-delivery-action="edit" data-id="${esc(a.id)}">EDIT</button><button class="danger" data-delivery-action="delete" data-id="${esc(a.id)}">DELETE</button></div></article>`).join(''):'<div class="empty"><b>NO DELIVERY APPS</b><span>Add a service above to show it on the customer ordering page.</span></div>';
  }
  function setupDeliveryApps(){
    const form=$("deliveryAppForm"),wrap=$("deliveryAppsManager"); if(!form||!wrap)return;
    form.addEventListener('submit',e=>{e.preventDefault();if(!roleCan('deliveryApps'))return;const name=$("deliveryAppName").value.trim(),url=$("deliveryAppUrl").value.trim(),note=$("deliveryAppNote").value.trim();try{new URL(url)}catch(err){alert('Please enter a valid delivery app URL.');return}const apps=getDeliveryApps();if(apps.some(a=>a.name.toLowerCase()===name.toLowerCase())){alert('That delivery app already exists.');return}apps.push({id:'delivery-'+Date.now().toString(36),name,url,note,active:true});saveDeliveryApps(apps);form.reset();renderDeliveryApps();saveToast('Delivery app added')});
    wrap.addEventListener('click',e=>{const b=e.target.closest('[data-delivery-action]');if(!b)return;const apps=getDeliveryApps(),i=apps.findIndex(a=>a.id===b.dataset.id);if(i<0)return;const action=b.dataset.deliveryAction;if(action==='delete'){if(!confirm(`Delete ${apps[i].name} from customer delivery options?`))return;apps.splice(i,1);saveDeliveryApps(apps);renderDeliveryApps();saveToast('Delivery app deleted')}else if(action==='edit'){const a=apps[i],name=prompt('Delivery app name',a.name),url=prompt('CUPCUT delivery page URL',a.url),note=prompt('Short note',a.note||'');if(name===null||url===null)return;try{new URL(url.trim())}catch(err){alert('Please enter a valid URL.');return}a.name=name.trim()||a.name;a.url=url.trim();if(note!==null)a.note=note.trim();saveDeliveryApps(apps);renderDeliveryApps();saveToast('Delivery app updated')}});
    wrap.addEventListener('change',e=>{const input=e.target.closest('[data-delivery-action="toggle"]');if(!input)return;const apps=getDeliveryApps(),i=apps.findIndex(a=>a.id===input.dataset.id);if(i<0)return;apps[i].active=input.checked;saveDeliveryApps(apps);renderDeliveryApps();saveToast(input.checked?'Delivery app shown':'Delivery app hidden')});
    renderDeliveryApps();
  }

  function roleCan(panel){
    if(!currentUser)return false;
    if(panel==="accounts"||panel==="branches")return currentUser.role==="owner";
    if(panel==="menu")return ["owner","manager"].includes(currentUser.role);
    if(panel==="tools"||panel==="deliveryApps")return ["owner","manager"].includes(currentUser.role);
    return true;
  }
  function setupNav(){
    const globalGroup=$("globalNavGroup"), toggle=$("globalAdminToggle");
    const globalPanels=["menuPanel","photosPanel","deliveryAppsPanel","toolsPanel","branchesPanel","accountsPanel"];
    document.querySelectorAll(".admin-tab[data-panel]").forEach(b=>{
      const panel=b.dataset.panel;
      const key=panel==="menuPanel"?"menu":panel==="toolsPanel"?"tools":panel==="deliveryAppsPanel"?"deliveryApps":panel==="accountsPanel"?"accounts":panel==="branchesPanel"?"branches":"workspace";
      const allowed=roleCan(key);
      b.classList.toggle("hidden",!allowed);
      b.onclick=()=>{
        if(!allowed)return;
        document.querySelectorAll(".admin-tab[data-panel]").forEach(x=>x.classList.remove("active"));
        document.querySelectorAll(".panel").forEach(x=>x.classList.add("hidden"));
        b.classList.add("active");$(panel).classList.remove("hidden");
        if(panel==="reportsPanel")renderReports();
        if(panel==="menuPanel")renderMenu();
        if(panel==="photosPanel")renderSitePhotos();
        if(panel==="accountsPanel")renderAccounts();
        if(panel==="toolsPanel"){renderAddOns();updateStorageSummary()}
        if(panel==="deliveryAppsPanel")renderDeliveryApps();
      };
    });
    if(toggle){
      toggle.classList.toggle("hidden",currentUser?.role!=="owner");
      toggle.textContent=globalAdminOpen?"✕ CLOSE GLOBAL ADMIN":"⚙ GLOBAL ADMIN";
      toggle.onclick=()=>{
        if(currentUser?.role!=="owner")return;
        globalAdminOpen=!globalAdminOpen;
        globalGroup?.classList.toggle("hidden",!globalAdminOpen);
        toggle.textContent=globalAdminOpen?"✕ CLOSE GLOBAL ADMIN":"⚙ GLOBAL ADMIN";
      };
    }
    if(globalGroup)globalGroup.classList.toggle("hidden",!(currentUser?.role==="owner"&&globalAdminOpen));
  }

  function renderStats(orders){
    const today=orders.filter(o=>isToday(o.createdAt));
    $("newCount").textContent=orders.filter(o=>o.status==="New").length;
    $("activeCount").textContent=orders.filter(o=>["Preparing","Ready"].includes(o.status)).length;
    $("todayCount").textContent=today.length;
    $("salesTotal").textContent=money(today.filter(o=>o.status!=="Cancelled").reduce((a,o)=>a+Number(o.total||0),0));
    const completed=today.filter(o=>o.status==="Completed");
    const avg=completed.length?completed.reduce((a,o)=>a+Number(o.total||0),0)/completed.length:0;
    const avgEl=document.getElementById("avgOrder");if(avgEl)avgEl.textContent=money(avg);
    const pendingEl=document.getElementById("pendingCount");if(pendingEl)pendingEl.textContent=orders.filter(o=>["New","Preparing","Ready"].includes(o.status)).length;
  }
  function matches(o){
    const statusOk=filter==="all"||o.status===filter;
    const hay=[o.id,o.customerName,o.customerPhone,o.orderType,o.deliveryPlatform,branchName(o.branchId)].join(" ").toLowerCase();
    const branchOk=branchFilter==="all"||o.branchId===branchFilter;
    return statusOk&&branchOk&&hay.includes(query.toLowerCase());
  }
  function itemHtml(i){
    const extras=[i.size,...(i.add||[]),i.note].filter(Boolean).join(" • ");
    return `<div class="item"><span><b>${esc(i.qty)}× ${esc(i.name)}</b>${extras?`<small>${esc(extras)}</small>`:""}</span><b>${money(Number(i.price)*Number(i.qty))}</b></div>`;
  }
  function actions(o){
    if(o.status==="Cancelled"||o.status==="Completed")return `<button data-action="delete" data-id="${esc(o.id)}">DELETE RECORD</button>`;
    const next=o.status==="New"?"Preparing":o.status==="Preparing"?"Ready":"Completed";
    return `<button class="primary" data-action="status" data-status="${next}" data-id="${esc(o.id)}">${next==="Completed"?"MARK COMPLETED":"MARK "+next.toUpperCase()}</button><button class="cancel" data-action="status" data-status="Cancelled" data-id="${esc(o.id)}">CANCEL</button>`;
  }
  function renderOrders(){
    const orders=normalizeOrderBranches();renderStats(workspaceBranch!=="all"?orders.filter(o=>o.branchId===workspaceBranch):(branchFilter==="all"?orders:orders.filter(o=>o.branchId===branchFilter)));
    const branchSelect=$("orderBranchFilter"); if(branchSelect){branchSelect.innerHTML=getBranches().filter(b=>b.active!==false).map(b=>`<option value="${esc(b.id)}">${esc(b.name)}</option>`).join("");branchSelect.value=workspaceBranch;branchSelect.disabled=true;}
    const visible=orders.filter(o=>scopedBranch(o.branchId||"main")).filter(matches);
    $("orders").innerHTML=visible.map(o=>`<article class="order order-clickable" data-id="${esc(o.id)}">
      <div class="order-head"><div><div class="order-id">${esc(o.id)}</div><div class="order-meta">${dateTime(o.createdAt)} • ${esc(branchName(o.branchId))} • ${esc(o.orderType||"Pickup")}${o.pickupTime?` • Pickup ${esc(o.pickupTime)}`:""}${o.deliveryPlatform?` • ${esc(o.deliveryPlatform)}`:""}</div></div><span class="badge ${esc(o.status)}">${esc(o.status)}</span></div>
      <div class="order-body"><div class="customer"><div class="branch-chip">📍 ${esc(branchName(o.branchId))}</div><strong>${esc(o.customerName||"No name")}</strong><span>☎ ${esc(o.customerPhone||"No phone")}</span>${o.customerEmail?`<span>✉ ${esc(o.customerEmail)}</span>`:""}<div class="items">${(o.items||[]).map(itemHtml).join("")}</div>${o.specialInstructions?`<div class="note"><b>NOTE:</b> ${esc(o.specialInstructions)}</div>`:""}</div><div class="total"><span>ORDER TOTAL</span><strong>${money(o.total)}</strong></div></div>
      <div class="actions">${actions(o)}</div></article>`).join("");
    $("empty").classList.toggle("hidden",visible.length!==0);
  }

  function renderMenu(){
    const content=getContent(), q=menuQuery.toLowerCase();
    const rows=getAllItems().filter(x=>(menuCategory==="all"||x[0]===menuCategory)&&(`${x[0]} ${x[1]}`.toLowerCase().includes(q)));
    $("menuManager").innerHTML=rows.map(x=>{
      const k=keyOf(x),o=content[k]||{}, price=o.price!==undefined?o.price:x[2], available=o.available!==false, image=o.image||x[3]||"", custom=!!x[5];
      return `<article class="menu-admin-card">
        <div class="menu-admin-photo ${image?"has-image":""}" ${image?`style="background-image:url('${image}')"`:""}>${image?"":"<span>NO PHOTO</span>"}</div>
        <div class="menu-admin-info"><div class="menu-admin-head"><div><b>${esc(x[1])}${custom?'<span class="custom-badge">CUSTOM</span>':''}</b><small>${esc(x[0])}</small></div><span class="availability ${available?"on":"off"}">${available?"AVAILABLE":"SOLD OUT"}</span></div>
        <div class="menu-edit-row"><label>PRICE<input class="menu-price" type="number" min="0" step="1" value="${price==null?"":esc(price)}" data-key="${esc(k)}"></label>
        <label class="upload-label">PHOTO<input class="menu-image" type="file" accept="image/*" data-key="${esc(k)}"></label></div>
        <div class="menu-actions"><button class="primary save-menu" data-key="${esc(k)}">SAVE</button><button class="secondary toggle-menu" data-key="${esc(k)}">${available?"MARK SOLD OUT":"MARK AVAILABLE"}</button>${image?`<button class="secondary remove-image" data-key="${esc(k)}">REMOVE PHOTO</button>`:""}${custom?`<button class="secondary delete-product" data-key="${esc(k)}">DELETE PRODUCT</button>`:""}</div></div>
      </article>`;
    }).join("");
  }

  function updateContent(key,patch){
    const c=getContent();c[key]={...(c[key]||{}),...patch};saveContent(c);
  }

  function renderAccounts(){
    const accounts=getAccounts();
    $("accountList").innerHTML=accounts.map((a,i)=>`<article class="account-card">
      <div><b>${esc(a.username)}</b><span class="role ${esc(a.role)}">${esc(a.role)}</span></div>
      ${a.username==="owner"?'<small>Primary owner account</small>':`<button class="danger small-danger" data-account-index="${i}">DELETE</button>`}
    </article>`).join("");
  }

  function renderBranches(){
    const branches=getBranches().filter(b=>b.active!==false);
    const count=$("branchCount"); if(count)count.textContent=branches.length;
    const label=$("branchCurrentLabel"); if(label)label.textContent=branchFilter==="all"?"ALL BRANCHES":branchName(branchFilter).toUpperCase();
    const list=$("branchList"); if(!list)return;
    list.innerHTML=branches.map(b=>{
      const n=getOrders().filter(o=>(o.branchId||"main")===b.id).length;
      const action=b.id!=="main"?`<button class="danger branch-toggle-btn" data-branch="${esc(b.id)}">DEACTIVATE</button>`:`<span class="branch-main-badge">DEFAULT</span>`;
      return `<article class="branch-card"><div class="branch-icon">📍</div><div class="branch-info"><span class="eyebrow">LOCATION</span><h3>${esc(b.name)}</h3><p>${n} order${n===1?"":"s"} assigned</p></div><div class="branch-actions"><button class="secondary branch-filter-btn" data-branch="${esc(b.id)}">VIEW ORDERS</button>${action}</div></article>`;
    }).join("");
  }

  function showOrderDetails(id){
    const o=getOrders().find(x=>x.id===id);if(!o)return;
    const modal=document.getElementById("orderModal"),box=document.getElementById("orderModalContent");
    box.innerHTML=`<div class="order-modal-head"><div><span class="eyebrow">ORDER DETAILS</span><h3>${esc(o.id)}</h3><div class="order-meta">${dateTime(o.createdAt)} • ${esc(branchName(o.branchId))} • ${esc(o.orderType||"Pickup")}${o.pickupTime?` • Pickup ${esc(o.pickupTime)}`:""}${o.deliveryPlatform?` • ${esc(o.deliveryPlatform)}`:""}</div></div><button class="modal-close" id="closeOrderModal">×</button></div>
    <p><b>${esc(o.customerName||"No name")}</b> · ${esc(o.customerPhone||"No phone")}${o.customerEmail?` · ✉ ${esc(o.customerEmail)}`:""}</p><div class="modal-branch-control"><label>RECEIVING BRANCH<select id="modalBranchSelect">${getBranches().filter(b=>b.active!==false).map(b=>`<option value="${esc(b.id)}" ${b.id===(o.branchId||"main")?"selected":""}>${esc(b.name)}</option>`).join("")}</select></label><button class="secondary" id="saveBranchBtn">SAVE BRANCH</button></div><p class="notification-info">Notification preference: <b>${esc((o.notificationPreference||"web").toUpperCase())}</b> · Customer can always track on the website.</p><p class="notification-info">Order: <b>${esc(o.orderType||"Pickup")}</b>${o.pickupTime?` · Pickup time: <b>${esc(o.pickupTime)}</b>`:""}${o.deliveryPlatform?` · Delivery platform: <b>${esc(o.deliveryPlatform)}</b>`:""} · Payment: <b>${esc(o.paymentMethod||"Cash")}</b>${o.paymentStatus?` · Payment status: ${esc(o.paymentStatus)}`:""}${o.deliveryAddress?`<br>Delivery address: ${esc(o.deliveryAddress)}`:""}</p>
    <div class="modal-lines">${(o.items||[]).map(i=>`<div class="modal-line"><span>${esc(i.qty)}× ${esc(i.name)}<small>${esc([i.size,...(i.add||[]),i.note].filter(Boolean).join(" • "))}</small></span><b>${money(Number(i.price)*Number(i.qty))}</b></div>`).join("")}</div>
    ${o.specialInstructions?`<div class="note"><b>NOTE:</b> ${esc(o.specialInstructions)}</div>`:""}<h3 style="text-align:right">${money(o.total)}</h3><div class="modal-actions"><button class="primary" id="printOrderBtn">PRINT ORDER</button><button class="secondary" id="copyOrderBtn">COPY ORDER</button><button class="secondary" id="modalStatusBtn">${o.status==="New"?"START PREPARING":o.status==="Preparing"?"MARK READY":o.status==="Ready"?"MARK COMPLETED":"CLOSE"}</button></div>`;
    modal.classList.add("show");modal.setAttribute("aria-hidden","false");
    document.getElementById("closeOrderModal").onclick=closeOrderModal;
    document.getElementById("saveBranchBtn").onclick=()=>{const branch=document.getElementById("modalBranchSelect").value;const a=getOrders();const i=a.findIndex(x=>x.id===o.id);if(i<0)return;a[i].branchId=branch;a[i].updatedAt=new Date().toISOString();saveOrders(a);renderOrders();renderBranches();saveToast(`Order assigned to ${branchName(branch)}`);};
    document.getElementById("printOrderBtn").onclick=()=>printOrder(o);
    document.getElementById("copyOrderBtn").onclick=async()=>{await navigator.clipboard?.writeText(orderPlain(o));saveToast("Order copied")};
    document.getElementById("modalStatusBtn").onclick=()=>{if(["Completed","Cancelled"].includes(o.status)){closeOrderModal();return}const next=o.status==="New"?"Preparing":o.status==="Preparing"?"Ready":"Completed";const a=getOrders();const i=a.findIndex(x=>x.id===o.id);a[i].status=next;a[i].updatedAt=new Date().toISOString();saveOrders(a);
    if(window.CAFE_API_ENABLED){
      fetch(window.CAFE_API_BASE_URL+"/orders/"+encodeURIComponent(o.id)+"/status",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({status:next, notify:true, notificationPreference:o.notificationPreference||"web", customer:{name:o.customerName||"", phone:o.customerPhone||"", email:o.customerEmail||""}})})
        .catch(()=>console.warn("Server status update failed; local status retained."));
    }
    closeOrderModal();renderOrders();saveToast(`Order ${next}`)};
    modal.onclick=e=>{if(e.target===modal)closeOrderModal()};
  }
  function closeOrderModal(){const m=document.getElementById("orderModal");m.classList.remove("show");m.setAttribute("aria-hidden","true")}
  function orderPlain(o){
    const lines=(o.items||[]).map(i=>{const opts=[i.size,...(i.add||[])].filter(Boolean).join(" • ");return `${i.qty}x ${i.name}${opts?" ("+opts+")":""} — ${money(i.price*i.qty)}`}).join("\n");
    return ["CUPCUT CAFE ORDER",o.id,"Branch: "+branchName(o.branchId),"Customer: "+(o.customerName||"No name"),"Phone: "+(o.customerPhone||"No phone"),"Type: "+(o.orderType||"Pickup"),o.pickupTime?"Pickup time: "+o.pickupTime:"",o.deliveryPlatform?"Delivery platform: "+o.deliveryPlatform:"","Status: "+o.status,"",lines,"","TOTAL: "+money(o.total),o.specialInstructions?"Note: "+o.specialInstructions:""] .filter(Boolean).join("\n");
  }
  function printOrder(o){
    const w=window.open("","_blank","width=520,height=700");if(!w){alert("Please allow pop-ups to print.");return}
    const lines=(o.items||[]).map(i=>{const opts=[i.size,...(i.add||[])].filter(Boolean).join(" • ");return `<div class="line"><span>${esc(i.qty)}× ${esc(i.name)}<small>${esc(opts)}</small></span><b>${money(i.price*i.qty)}</b></div>`}).join("");
    const note=o.specialInstructions?`<p><b>NOTE:</b> ${esc(o.specialInstructions)}</p>`:"";
    const html=`<html><head><title>${esc(o.id)}</title><style>body{font-family:Arial;padding:24px;max-width:420px;margin:auto}h1{font-size:24px}small{display:block;color:#666}.line{display:flex;justify-content:space-between;border-bottom:1px solid #ddd;padding:8px 0}button{padding:10px;margin-top:16px}@media print{button{display:none}}</style></head><body><h1>CUPCUT CAFE</h1><p><b>${esc(o.id)}</b><br><b>Branch:</b> ${esc(branchName(o.branchId))}<br>${esc(o.customerName||"No name")}<br>${esc(o.customerPhone||"No phone")}<br>${dateTime(o.createdAt)} · ${esc(o.orderType||"Pickup")}${o.pickupTime?` · Pickup ${esc(o.pickupTime)}`:""}${o.deliveryPlatform?` · ${esc(o.deliveryPlatform)}`:""}</p>${lines}<h2 style="text-align:right">${money(o.total)}</h2>${note}<button onclick="print()">PRINT</button></body></html>`;
    w.document.write(html);w.document.close();w.focus();setTimeout(()=>w.print(),250);
  }

  const togglePassword=$("togglePassword");
  if(togglePassword){togglePassword.onclick=()=>{const input=$("adminPassword");const visible=input.type==="text";input.type=visible?"password":"text";togglePassword.textContent=visible?"SHOW":"HIDE";togglePassword.setAttribute("aria-label",visible?"Show password":"Hide password")}}

  const workspaceBranchSelect=$("workspaceBranchSelect");
  if(workspaceBranchSelect){
    workspaceBranchSelect.addEventListener("change",e=>{
      workspaceBranch=e.target.value;
      try{localStorage.setItem("cupcut-workspace-branch",workspaceBranch)}catch(e){}
      globalAdminOpen=false;
      branchFilter=workspaceBranch;reportBranch=workspaceBranch;graphBranch=workspaceBranch;
      applyWorkspace();setupNav();renderOrders();renderBranches();if(document.getElementById("reportsPanel")&&!document.getElementById("reportsPanel").classList.contains("hidden"))renderReports();
      saveToast(workspaceLabel()+" workspace selected");
    });
  }

  $("loginForm").addEventListener("submit",e=>{
    e.preventDefault();
    const username=$("adminUsername").value.trim().toLowerCase(),password=$("adminPassword").value;
    const account=getAccounts().find(a=>a.username===username&&a.password===password);
    if(!account){$("loginError").textContent="Incorrect username or password. Check your credentials and try again.";$("adminPassword").select();return}
    currentUser=account;
    try{sessionStorage.setItem("cafe-template-admin-user",JSON.stringify({username:account.username,role:account.role}))}catch(e){}
    $("loginScreen").classList.add("hidden");$("app").classList.remove("hidden");
    $("loggedUser").textContent=`Signed in as ${account.username} • ${account.role.toUpperCase()}`;
    setupNav();applyWorkspace();renderOrders();renderBranches();
  });

  function initWorkspace(){
    try{const saved=localStorage.getItem("cupcut-workspace-branch");if(saved&&saved!=="all")workspaceBranch=saved;}catch(e){}
    applyWorkspace();
  }

  initWorkspace();

  function boot(){
    // Always initialize the local account store before attempting session restore.
    getAccounts();
    let raw=null; try{raw=sessionStorage.getItem("cafe-template-admin-user")}catch(e){}
    if(raw){
      try{
        const s=JSON.parse(raw), account=getAccounts().find(a=>a.username===s.username&&a.role===s.role);
        if(account){currentUser=account;$("loginScreen").classList.add("hidden");$("app").classList.remove("hidden");$("loggedUser").textContent=`Signed in as ${account.username} • ${account.role.toUpperCase()}`;setupNav();applyWorkspace();renderOrders();renderBranches();return}
      }catch(e){}
    }
    getAccounts();
  }

  $("logoutBtn").onclick=()=>{try{sessionStorage.removeItem("cafe-template-admin-user")}catch(e){};location.reload()};
  $("refreshBtn").onclick=renderOrders;
  $("searchOrders").oninput=e=>{query=e.target.value;renderOrders()};
  $("orderBranchFilter").onchange=e=>{branchFilter=e.target.value;renderOrders();renderBranches()};
  document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
    document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));
    b.classList.add("active");filter=b.dataset.filter;renderOrders();
  });

  $("orders").addEventListener("click",e=>{
    const action=e.target.closest("button[data-action]");
    if(!action){const card=e.target.closest(".order-clickable");if(card){showOrderDetails(card.dataset.id)}return}
    const b=action;
    const orders=getOrders(),idx=orders.findIndex(o=>o.id===b.dataset.id);if(idx<0)return;
    if(b.dataset.action==="delete"){if(confirm("Delete this order record?")){orders.splice(idx,1);saveOrders(orders);renderOrders()}}
    else{orders[idx].status=b.dataset.status;orders[idx].updatedAt=new Date().toISOString();saveOrders(orders);renderOrders()}
  });

  $("exportBtn").onclick=()=>{
    const rows=[["Order ID","Date","Branch","Customer","Phone","Order Type","Status","Items","Total","Special Instructions"]];
    getOrders().filter(o=>scopedBranch(o.branchId||"main")).forEach(o=>rows.push([o.id,dateTime(o.createdAt),branchName(o.branchId),o.customerName,o.customerPhone,o.orderType,o.status,(o.items||[]).map(i=>`${i.qty}x ${i.name}${i.size?` (${i.size})`:""}`).join(" | "),o.total,o.specialInstructions||""]));
    const csv=rows.map(r=>r.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}),a=document.createElement("a");
    a.href=URL.createObjectURL(blob);a.download=`cafe-template-orders-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(a.href);
  };

  const adminThemeKey="cafe-template-admin-theme";
  function applyAdminTheme(theme){
    const dark=theme==="dark";
    document.documentElement.setAttribute("data-theme",dark?"dark":"light");
    document.body.classList.toggle("dark",dark);
    const b=$("themeBtn");
    if(b){b.textContent=dark?"☀ Light":"◐ Dark";b.setAttribute("aria-label",dark?"Switch to light theme":"Switch to dark theme");}
  }
  let savedAdminTheme="light";
  try{savedAdminTheme=localStorage.getItem(adminThemeKey)==="dark"?"dark":"light"}catch(e){}
  applyAdminTheme(savedAdminTheme);
  $("themeBtn").onclick=()=>{
    const next=document.documentElement.getAttribute("data-theme")==="dark"?"light":"dark";
    try{localStorage.setItem(adminThemeKey,next)}catch(e){saveToast("Theme could not be saved in this browser")}
    applyAdminTheme(next);
  };

  document.querySelectorAll(".report-period").forEach(b=>b.onclick=()=>{document.querySelectorAll(".report-period").forEach(x=>x.classList.remove("active"));b.classList.add("active");reportPeriod=b.dataset.period;$("customRange").classList.toggle("hidden",reportPeriod!=="custom");renderReports()});
  $("applyReportRange").onclick=()=>{reportFrom=$("reportFrom").value;reportTo=$("reportTo").value;if(reportFrom&&reportTo&&reportFrom>reportTo){alert("The FROM date must be before the TO date.");return}renderReports()};
  $("exportReportBtn").onclick=exportReport;
  $("reportBranchSelect").onchange=e=>{reportBranch=workspaceBranch;renderReports()};
  $("graphBranchSelect").onchange=e=>{graphBranch=workspaceBranch;renderReports()};
  $("branchRecords").addEventListener("click",e=>{const b=e.target.closest(".branch-report-btn");if(!b)return;reportBranch=b.dataset.branch;renderReports()});

  $("menuSearch").oninput=e=>{menuQuery=e.target.value;renderMenu()};
  $("menuCategory").onchange=e=>{menuCategory=e.target.value;renderMenu()};
  const cats=[...new Set(getAllItems().map(x=>x[0]))];
  cats.forEach(c=>{const o=document.createElement("option");o.value=c;o.textContent=c;$("menuCategory").appendChild(o)});

  $("productForm").addEventListener("submit",e=>{e.preventDefault();if(!roleCan("menu"))return;const category=$("newProductCategory").value.trim(),name=$("newProductName").value.trim(),price=Number($("newProductPrice").value);if(!category||!name||!Number.isFinite(price)){alert("Please complete the product fields.");return}const c=getContent();c.customProducts=Array.isArray(c.customProducts)?c.customProducts:[];if(getAllItems().some(x=>x[0]===category&&x[1].toLowerCase()===name.toLowerCase())){alert("That product already exists.");return}c.customProducts.push({category,name,price,available:true});saveContent(c);$("productForm").reset();if(![...document.querySelectorAll("#menuCategory option")].some(o=>o.value===category)){const op=document.createElement("option");op.value=category;op.textContent=category;$("menuCategory").appendChild(op)}renderMenu();saveToast("Product added")});

  function findMenuField(cls,key){
    return [...document.querySelectorAll("."+cls)].find(el=>el.dataset.key===key)||null;
  }
  async function readAndCompressImage(file,maxSide=1600,quality=.82){
    return new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onerror=()=>reject(reader.error||new Error("Could not read image"));
      reader.onload=()=>{
        const img=new Image();
        img.onerror=()=>reject(new Error("Invalid image"));
        img.onload=()=>{
          const scale=Math.min(1,maxSide/Math.max(img.naturalWidth,img.naturalHeight));
          const w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale));
          const canvas=document.createElement("canvas");canvas.width=w;canvas.height=h;
          const ctx=canvas.getContext("2d");ctx.drawImage(img,0,0,w,h);
          resolve(canvas.toDataURL("image/jpeg",quality));
        };
        img.src=reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  $("menuManager").addEventListener("click",async e=>{
    const b=e.target.closest("button[data-key]");if(!b)return;
    const key=b.dataset.key;
    if(b.classList.contains("save-menu")){
      const input=findMenuField("menu-price",key);
      const file=findMenuField("menu-image",key);
      const patch={};
      if(input)patch.price=input.value===""?null:Number(input.value);
      if(file&&file.files[0]){
        if(file.files[0].size>2*1024*1024){alert("Please use an image under 2 MB.");return}
        try{
          const image=await readAndCompressImage(file.files[0]);
          updateContent(key,{...patch,image});
          renderMenu();
          saveToast("Menu item saved");
        }catch(err){alert("Could not process that image. Please try another photo.");}
        return;
      }
      updateContent(key,patch);renderMenu();
    }
    if(b.classList.contains("toggle-menu")){
      const c=getContent(),o=c[key]||{};updateContent(key,{available:o.available===false});renderMenu();
    }
    if(b.classList.contains("remove-image")){updateContent(key,{image:""});renderMenu()}
    if(b.classList.contains("delete-product")){if(!confirm("Delete this custom product?"))return;const c=getContent();c.customProducts=(c.customProducts||[]).filter(x=>keyOf([x.category,x.name])!==key);saveContent(c);renderMenu();saveToast("Product deleted")}
  });

  document.querySelectorAll(".site-photo-input").forEach(input=>{
    input.addEventListener("change",e=>{
      const file=e.target.files&&e.target.files[0]; if(!file)return;
      if(file.size>2*1024*1024){alert("Please use an image under 2 MB.");e.target.value="";return}
      if(!file.type.startsWith("image/")){alert("Please choose an image file.");e.target.value="";return}
      readAndCompressImage(file).then(image=>{
        const photos=getSitePhotos();photos[input.dataset.photo]=image;saveSitePhotos(photos);renderSitePhotos();saveToast("Cafe photo updated");
      }).catch(()=>alert("Could not process that image. Please try another photo."));
    });
  });
  document.querySelectorAll(".remove-site-photo").forEach(btn=>btn.addEventListener("click",()=>{
    const photos=getSitePhotos();delete photos[btn.dataset.photo];saveSitePhotos(photos);renderSitePhotos();saveToast("Photo removed");
  }));
  $("resetPhotosBtn").onclick=()=>{if(confirm("Remove all cafe gallery and owner/team photos from this browser?")){localStorage.removeItem(SITE_PHOTOS_KEY);renderSitePhotos();saveToast("Photos reset")}};
  renderSitePhotos();

  $("resetContentBtn").onclick=()=>{
    if(confirm("Reset all local menu price/photo/availability changes?")){localStorage.removeItem(CONTENT_KEY);renderMenu()}
  };

  setupDeliveryApps();

  function updateStorageSummary(){let bytes=0;for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i)||"";bytes+=k.length+(localStorage.getItem(k)||"").length}const kb=(bytes/1024).toFixed(1);const el=$("storageSummary");if(el)el.innerHTML=`About <b>${kb} KB</b> currently stored in this browser.<br>Data keys: ${localStorage.length}`}
  function backupData(){const data={version:"CAFE-LOCAL-ADMIN-TEMPLATE",exportedAt:new Date().toISOString(),orders:getOrders(),accounts:getAccounts(),content:getContent(),theme:localStorage.getItem("cafe-template-admin-theme")||"light",branches:getBranches()};const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`cafe-local-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);saveToast("Backup downloaded")}
  $("backupBtn").onclick=backupData;$("refreshStorageBtn").onclick=updateStorageSummary;$("restoreFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(!data||!Array.isArray(data.orders)||!Array.isArray(data.accounts)||!data.content)throw Error();if(!confirm("Restore this backup and replace current local data?"))return;localStorage.setItem(ORDERS_KEY,JSON.stringify(data.orders));localStorage.setItem(ACCOUNTS_KEY,JSON.stringify(data.accounts));localStorage.setItem(CONTENT_KEY,JSON.stringify(data.content));if(data.theme)localStorage.setItem("cafe-template-admin-theme",data.theme);if(Array.isArray(data.branches))localStorage.setItem(BRANCHES_KEY,JSON.stringify(data.branches));location.reload()}catch(err){alert("Invalid cafe template backup file.")}};
  $("clearOldOrdersBtn").onclick=()=>{if(!roleCan("accounts"))return;const o=getOrders(),old=o.filter(x=>["Completed","Cancelled"].includes(x.status)).length;if(!old){alert("There are no completed/cancelled records to clear.");return}if(confirm(`Delete ${old} completed/cancelled order records?`)){saveOrders(o.filter(x=>!["Completed","Cancelled"].includes(x.status)));renderOrders();saveToast("Old orders cleared")}};
  function renderAddOns(){const a=getAddOns(),groups=["drink","food","cake"];$("addonManager").innerHTML=groups.flatMap(g=>(Array.isArray(a[g])?a[g]:[]).map((v,i)=>{const m=String(v).match(/^(.*?)(?:\s*\+₱(\d+))?$/);return `<div class="addon-row"><label>${g.toUpperCase()}<input class="addon-input" data-group="${g}" data-index="${i}" value="${esc(v)}"></label><button class="primary save-addon" data-group="${g}" data-index="${i}">SAVE</button></div>`})).join("")}
  $("addonManager").addEventListener("click",e=>{const b=e.target.closest(".save-addon");if(!b)return;const input=b.parentElement.querySelector(".addon-input"),c=getContent(),a=getAddOns();a[b.dataset.group][Number(b.dataset.index)]=input.value.trim();c.addOns=a;saveContent(c);saveToast("Add-on saved")});

  $("accountForm").addEventListener("submit",e=>{
    e.preventDefault();
    if(!roleCan("accounts"))return;
    const username=$("newUsername").value.trim(),password=$("newPassword").value,role=$("newRole").value;
    if(!/^[a-zA-Z0-9._-]{3,30}$/.test(username)){alert("Username must be 3–30 letters/numbers and may include . _ -.");return}
    const accounts=getAccounts();
    if(accounts.some(a=>a.username.toLowerCase()===username.toLowerCase())){alert("That username already exists.");return}
    accounts.push({username,password,role});saveAccounts(accounts);
    $("accountForm").reset();renderAccounts();
  });

  $("accountList").addEventListener("click",e=>{
    const b=e.target.closest("[data-account-index]");if(!b)return;
    const idx=Number(b.dataset.accountIndex),accounts=getAccounts(),a=accounts[idx];
    if(!a||a.username==="owner")return;
    if(confirm(`Delete ${a.username}?`)){accounts.splice(idx,1);saveAccounts(accounts);renderAccounts()}
  });

  $("branchForm").addEventListener("submit",e=>{e.preventDefault();if(!roleCan("accounts"))return;const name=$("newBranchName").value.trim();if(name.length<2){alert("Please enter a branch name.");return}const branches=getBranches();if(branches.some(b=>b.name.toLowerCase()===name.toLowerCase())){alert("That branch already exists.");return}const baseId=name.toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"")||"branch";
    let id=baseId, n=2;
    while(branches.some(b=>b.id===id)) id=`${baseId}-${n++}`;
    branches.push({id,name,active:true});saveBranches(branches);$("branchForm").reset();renderBranches();renderOrders();saveToast("Branch added")});
  $("branchList").addEventListener("click",e=>{const view=e.target.closest(".branch-filter-btn"),toggle=e.target.closest(".branch-toggle-btn");if(view){branchFilter=view.dataset.branch;$("orderBranchFilter").value=branchFilter;renderBranches();document.querySelector('[data-panel="ordersPanel"]').click();renderOrders();return}if(toggle){const branches=getBranches(),b=branches.find(x=>x.id===toggle.dataset.branch);if(!b)return;if(!confirm(`Deactivate ${b.name}? Existing orders will remain visible in history.`))return;b.active=false;if(branchFilter===b.id)branchFilter="all";saveBranches(branches);renderBranches();renderOrders();saveToast("Branch deactivated")}});

  function refreshFromBrowser(){
    if(!currentUser)return;
    renderOrders();
    renderBranches();
    if(document.querySelector("#reportsPanel:not(.hidden)"))renderReports();
    if(document.querySelector("#menuPanel:not(.hidden)"))renderMenu();
    renderSitePhotos();
  }
  window.addEventListener("storage",e=>{
    if(e.key===ORDERS_KEY){refreshFromBrowser();saveToast("Order data updated");}
    if(e.key===BRANCHES_KEY&&currentUser){renderBranches();renderOrders();}
    if(e.key===ACCOUNTS_KEY&&currentUser)renderAccounts();
    if(e.key===CONTENT_KEY&&currentUser)renderMenu();
    if(e.key===SITE_PHOTOS_KEY&&currentUser)renderSitePhotos();
  });
  window.addEventListener("cupcut-orders-updated",()=>refreshFromBrowser());
  // Polling makes the local-only setup reliable even in browsers that do not
  // fire storage events consistently between local files/tabs.
  let lastOrderSnapshot="";
  setInterval(()=>{
    if(!currentUser)return;
    const snapshot=JSON.stringify(getOrders());
    if(snapshot!==lastOrderSnapshot){lastOrderSnapshot=snapshot;renderOrders();}
  },1000);

  window.__cupcutRenderOrders=renderOrders;
  window.__cupcutRefreshOrders=refreshFromBrowser;
  boot();
})();
/* ===== V23 SERVER SYNC =====
   API contract:
   GET  /orders?admin=1              -> array of orders
   POST /orders                      -> order JSON
   GET  /orders/:id?phone=...        -> one order
   PATCH /orders/:id/status          -> {status:"Preparing"}
*/
(function(){
  if(!window.CAFE_API_ENABLED)return;
  async function sync(){
    try{
      const r=await fetch(window.CAFE_API_BASE_URL+"/orders?admin=1",{headers:{"Accept":"application/json"}});
      if(!r.ok)return;
      const data=await r.json();
      if(Array.isArray(data)){
        localStorage.setItem("cafe-template-orders",JSON.stringify(data));
        if(typeof window.__cupcutRenderOrders==="function")window.__cupcutRenderOrders();
      }
    }catch(e){}
  }
  sync();
  setInterval(sync,10000);
})();
