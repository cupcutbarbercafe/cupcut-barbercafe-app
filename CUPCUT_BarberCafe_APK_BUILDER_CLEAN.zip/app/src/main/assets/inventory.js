(() => {
  const KEY = 'cafe-template-inventory-v1';
  const TX_KEY = 'cafe-template-inventory-transactions-v1';
  const $ = id => document.getElementById(id);
  const money = n => '₱' + Number(n || 0).toLocaleString('en-PH', {minimumFractionDigits:2, maximumFractionDigits:2});
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const read = (k, fallback) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? fallback; } catch { return fallback; } };
  const write = (k,v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { alert('Could not save inventory data in this browser.'); return false; } };
  const getBranches = () => {
    const stored = read('cafe-template-branches', null);
    if (Array.isArray(stored) && stored.length) return stored;
    return [{id:'main',name:'Main Branch',active:true},{id:'branch-2',name:'Branch 2',active:true}];
  };
  const getItems = () => { const a=read(KEY,[]); return Array.isArray(a)?a:[]; };
  const getTx = () => { const a=read(TX_KEY,[]); return Array.isArray(a)?a:[]; };
  const saveItems = a => write(KEY,a);
  const saveTx = a => write(TX_KEY,a);
  const branchName = id => getBranches().find(b=>b.id===id)?.name || 'Unassigned';
  const workspaceBranch = () => { try { const v=localStorage.getItem(WORKSPACE_KEY); return v && v!=='all' ? v : (getBranches()[0]?.id||'main'); } catch(e){ return getBranches()[0]?.id||'main'; } };
  const uid = p => p + '-' + Date.now().toString(36) + Math.random().toString(36).slice(2,7);

  function activeRole(){
    try { const s=JSON.parse(sessionStorage.getItem('cafe-template-admin-user')||'null'); return s?.role || ''; } catch { return ''; }
  }
  function canEdit(){ return ['owner','manager'].includes(activeRole()); }

  function render(){
    const items=getItems();
    const ws=workspaceBranch();
    const active=items.filter(x=>x.active!==false&&x.branchId===ws);
    const low=active.filter(x=>Number(x.onHand)<=Number(x.reorderLevel));
    const out=active.filter(x=>Number(x.onHand)<=0);
    const value=active.reduce((s,x)=>s+Number(x.onHand||0)*Number(x.cost||0),0);
    $('invTotalItems').textContent=active.length;
    $('invLowStock').textContent=low.length;
    $('invOutStock').textContent=out.length;
    $('invStockValue').textContent=money(value);
    const branchFilter=ws;
    const category=$('inventoryCategoryFilter')?.value||'all';
    const q=($('inventorySearch')?.value||'').trim().toLowerCase();
    const filtered=items.filter(x=>{
      if(branchFilter!=='all'&&x.branchId!==branchFilter)return false;
      if(category!=='all'&&x.category!==category)return false;
      if(q&&!`${x.name} ${x.sku||''} ${x.supplier||''} ${x.category}`.toLowerCase().includes(q))return false;
      return true;
    });
    $('inventoryTable').innerHTML=filtered.length ? filtered.map(x=>{
      const qty=Number(x.onHand||0), reorder=Number(x.reorderLevel||0), state=qty<=0?'OUT OF STOCK':qty<=reorder?'LOW STOCK':'IN STOCK';
      return `<article class="inventory-row ${qty<=reorder?'inventory-alert':''}">
        <div class="inv-main"><strong>${esc(x.name)}</strong><span>${esc(x.sku||'NO SKU')} · ${esc(x.category||'Uncategorized')}</span></div>
        <div><span class="inv-label">BRANCH</span><b>${esc(branchName(x.branchId))}</b></div>
        <div><span class="inv-label">ON HAND</span><b>${qty.toLocaleString()} ${esc(x.unit||'unit')}</b></div>
        <div><span class="inv-label">REORDER AT</span><b>${reorder.toLocaleString()}</b></div>
        <div><span class="inv-label">COST</span><b>${money(x.cost)}</b></div>
        <div><span class="inventory-status ${qty<=0?'is-out':qty<=reorder?'is-low':'is-ok'}">${state}</span></div>
        <div class="inventory-actions"><button class="secondary inv-action" data-action="receive" data-id="${esc(x.id)}">RECEIVE</button><button class="secondary inv-action" data-action="adjust" data-id="${esc(x.id)}">ADJUST</button><button class="secondary inv-action" data-action="waste" data-id="${esc(x.id)}">WASTE</button><button class="danger inv-action" data-action="delete" data-id="${esc(x.id)}">DELETE</button></div>
      </article>`;
    }).join('') : `<div class="inventory-empty"><b>NO INVENTORY ITEMS</b><span>Add ingredients, packaging, supplies, or retail stock above. Stock stays separate by branch.</span></div>`;
    renderFilters(items); renderTransactions();
  }
  function renderFilters(items){
    const cats=[...new Set(items.map(x=>x.category).filter(Boolean))].sort();
    const old=$('inventoryCategoryFilter').value;
    $('inventoryCategoryFilter').innerHTML='<option value="all">ALL CATEGORIES</option>'+cats.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');
    $('inventoryCategoryFilter').value=cats.includes(old)?old:'all';
    const b=$('inventoryBranchFilter'), ws=workspaceBranch();
    b.innerHTML=getBranches().filter(x=>x.active!==false&&x.id===ws).map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');
    b.value=ws; b.disabled=true;
  }
  function renderTransactions(){
    const tx=getTx().filter(t=>t.branchId===workspaceBranch()).slice(0,30);
    $('inventoryTransactions').innerHTML=tx.length?tx.map(t=>`<div class="inventory-tx"><div><strong>${esc(t.type)}</strong><span>${esc(t.itemName)} · ${esc(branchName(t.branchId))}</span></div><b class="tx-${t.type.toLowerCase()}">${t.type==='WASTE'||t.type==='ADJUSTMENT'&&t.delta<0?'−':'+'}${Math.abs(Number(t.delta||0)).toLocaleString()} ${esc(t.unit||'unit')}</b><small>${new Date(t.at).toLocaleString('en-PH')}</small></div>`).join(''):'<div class="inventory-empty compact"><span>No stock movements recorded yet.</span></div>';
  }
  function addTx(item,type,delta,note){
    const tx=getTx();tx.unshift({id:uid('tx'),itemId:item.id,itemName:item.name,branchId:item.branchId,type,delta,unit:item.unit,at:new Date().toISOString(),note:note||''});saveTx(tx.slice(0,500));
  }
  function mutate(id, type){
    const items=getItems(), i=items.findIndex(x=>x.id===id); if(i<0)return; const item=items[i];
    if(!canEdit()){alert('Inventory changes are available to owners and managers.');return;}
    if(type==='delete'){if(!confirm(`Delete ${item.name} from inventory? Its transaction history will remain.`))return;item.active=false;saveItems(items);render();return;}
    const promptText=type==='receive'?'Quantity received:':type==='waste'?'Quantity wasted:':'Adjustment amount (use a negative number to remove stock):';
    const raw=prompt(promptText,'0'); if(raw===null)return; const n=Number(raw); if(!Number.isFinite(n)||n<=0&&type!=='adjust'){alert('Enter a valid quantity.');return}
    let delta=type==='receive'?n:type==='waste'?-n:n; if(type==='waste'&&n>Number(item.onHand||0)){alert('Waste quantity cannot exceed current stock.');return}
    if(type==='adjust'&&n===0){alert('Enter an amount other than zero.');return}
    item.onHand=Math.max(0,Number(item.onHand||0)+delta);saveItems(items);addTx(item,type==='receive'?'RECEIVED':type==='waste'?'WASTE':'ADJUSTMENT',delta);render();
  }
  function openEdit(id){
    const item=getItems().find(x=>x.id===id); if(!item||!canEdit())return;
    const branch=getBranches().find(b=>b.id===item.branchId)?.name||'';
    const name=prompt('Item name',item.name); if(name===null)return;
    const sku=prompt('SKU / code',item.sku||''); if(sku===null)return;
    const category=prompt('Category',item.category||'Ingredient'); if(category===null)return;
    const unit=prompt('Unit (kg, L, pcs, bottle, pack...)',item.unit||'unit'); if(unit===null)return;
    const cost=prompt('Unit cost',String(item.cost??0)); if(cost===null)return;
    const reorder=prompt('Reorder level',String(item.reorderLevel??0)); if(reorder===null)return;
    const supplier=prompt('Supplier',item.supplier||''); if(supplier===null)return;
    Object.assign(item,{name:name.trim()||item.name,sku:sku.trim(),category:category.trim()||'Uncategorized',unit:unit.trim()||'unit',cost:Math.max(0,Number(cost)||0),reorderLevel:Math.max(0,Number(reorder)||0),supplier:supplier.trim()});
    const items=getItems();saveItems(items);render();
  }
  function addItem(e){
    e.preventDefault(); if(!canEdit()){alert('Inventory changes are available to owners and managers.');return;}
    const name=$('invName').value.trim(), sku=$('invSku').value.trim(), category=$('invCategory').value.trim(), unit=$('invUnit').value.trim(), branchId=workspaceBranch(), onHand=Number($('invOnHand').value)||0, reorder=Number($('invReorder').value)||0, cost=Number($('invCost').value)||0, supplier=$('invSupplier').value.trim();
    if(name.length<2){alert('Enter an inventory item name.');return} if(!branchId){alert('Choose a branch.');return}
    const items=getItems(); if(items.some(x=>x.active!==false&&x.name.toLowerCase()===name.toLowerCase()&&x.branchId===branchId)){alert('That inventory item already exists for this branch.');return}
    const item={id:uid('inv'),name,sku,category:category||'Uncategorized',unit:unit||'unit',branchId,onHand:Math.max(0,onHand),reorderLevel:Math.max(0,reorder),cost:Math.max(0,cost),supplier,active:true,createdAt:new Date().toISOString()};items.push(item);saveItems(items);
    if(onHand>0)addTx(item,'OPENING STOCK',onHand,''); e.target.reset(); $('invUnit').value='pcs'; render();
  }
  function exportCSV(){
    const rows=[['SKU','Item','Category','Branch','Unit','On Hand','Reorder Level','Unit Cost','Stock Value','Supplier','Status']];
    getItems().filter(x=>x.active!==false&&x.branchId===workspaceBranch()).forEach(x=>{const q=Number(x.onHand||0);rows.push([x.sku||'',x.name,x.category||'',branchName(x.branchId),x.unit||'',q,Number(x.reorderLevel||0),Number(x.cost||0),(q*Number(x.cost||0)).toFixed(2),x.supplier||'',q<=0?'OUT OF STOCK':q<=Number(x.reorderLevel||0)?'LOW STOCK':'IN STOCK'])});
    const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=`cupcut-inventory-${new Date().toISOString().slice(0,10)}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);
  }
  function init(){
    const tab=document.querySelector('.admin-tab[data-panel="inventoryPanel"]'); if(!tab)return;
    tab.addEventListener('click',()=>{render();});
    $('inventoryForm').addEventListener('submit',addItem);
    ['inventorySearch','inventoryBranchFilter','inventoryCategoryFilter'].forEach(id=>$(id).addEventListener(id==='inventorySearch'?'input':'change',render));
    $('inventoryTable').addEventListener('click',e=>{const b=e.target.closest('.inv-action');if(!b)return;if(b.dataset.action==='edit')openEdit(b.dataset.id);else mutate(b.dataset.id,b.dataset.action)});
    $('inventoryTable').addEventListener('dblclick',e=>{const row=e.target.closest('.inventory-row');if(row){const b=row.querySelector('[data-action="adjust"]');if(b)openEdit(b.dataset.id)}});
    $('exportInventoryBtn').addEventListener('click',exportCSV);
    $('inventoryResetBtn').addEventListener('click',()=>{if(!canEdit())return;if(confirm(`Delete ALL inventory items and stock history for ${branchName(workspaceBranch())}? This cannot be undone.`)){const ws=workspaceBranch();saveItems(getItems().map(x=>x.branchId===ws?{...x,active:false}:x));saveTx(getTx().filter(t=>t.branchId!==ws));render();}});
    const branches=getBranches(), ws=workspaceBranch();$('invBranch').innerHTML=branches.filter(x=>x.active!==false&&x.id===ws).map(x=>`<option value="${esc(x.id)}">${esc(x.name)}</option>`).join('');$('invBranch').value=ws;$('invBranch').disabled=true;
    $('invUnit').value='pcs'; render();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
